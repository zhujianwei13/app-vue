module.exports = {
  NODE_ENV: '"production"',
  API_ROOT: '"http://106.14.247.14:8081/yls"'
}
