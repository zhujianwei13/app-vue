import * as types from './mutation-types'
import {saveUser,deleteUser,clearUser,saveStatistics} from 'assets/js/cache'

export const saveUserHistory = function ({commit}, query) {
  commit(types.SET_USER_HISTORY, saveUser(query))
}

export const deleteUserHistory = function ({commit}, query) {
  commit(types.SET_USER_HISTORY, deleteUser(query))
}

export const clearUserHistory = function ({commit}) {
  commit(types.SET_USER_HISTORY, clearUser())
}
export const saveStatisticsRecord = function ({commit}, query) {
  commit(types.SET_STATISTICS_RECORD, saveStatistics(query))
}
