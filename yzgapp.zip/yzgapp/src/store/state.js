import {playMode} from 'assets/js/config'
import {loadUser,loadStatistics} from 'assets/js/cache'

const state = {
  audit: {},
  singer: {},
  playing: false,
  fullScreen: false,
  playlist: [],
  sequenceList: [],
  currentIndex: -1,
  disc: {},
  topList: {},
  userHistory: loadUser(),
  statisticsRecord: loadStatistics()
}

export default state
