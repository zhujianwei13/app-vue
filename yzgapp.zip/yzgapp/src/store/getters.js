export const audit = state => state.audit

export const userHistory = state => state.userHistory

export const statisticsRecord = state => state.statisticsRecord
