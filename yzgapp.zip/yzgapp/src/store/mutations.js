import * as types from './mutation-types'

const matutaions = {
  [types.SET_AUDIT](state, audit) {
    state.audit = audit
  },
  [types.SET_USER_HISTORY](state, userInfo) {
    state.userHistory = userInfo
  },
  [types.SET_STATISTICS_RECORD](state, statisticsInfo) {
    state.statisticsRecord = statisticsInfo
  }
}

export default matutaions
