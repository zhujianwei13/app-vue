import Vue from 'vue'
import Router from 'vue-router'
Vue.use(Router)
const Index = (resolve) => {
  import('@/components/index/index').then((module) => {
    resolve(module)
  })
}
const guide = (resolve) => {
  import('@/components/guide/guide').then((module) => {
    resolve(module)
  })
}
const login = (resolve) => {
  import('@/components/login/login').then((module) => {
    resolve(module)
  })
}
const register = (resolve) => {
  import('@/components/register/register').then((module) => {
    resolve(module)
  })
}
const storeList = (resolve) => {
  import('@/components/purchase/store/list').then((module) => {
    resolve(module)
  })
}
const auditView = (resolve) => {
  import('@/components/purchase/store/view').then((module) => {
    resolve(module)
  })
}
const purchaseOrderView = (resolve) => {
  import('@/components/purchase/purchaseOrder/view').then((module) => {
    resolve(module)
  })
}
const purchaseBackView = (resolve) => {
  import('@/components/purchase/purchaseBack/view').then((module) => {
    resolve(module)
  })
}
const advanceOrderView = (resolve) => {
  import('@/components/purchase/advanceOrder/view').then((module) => {
    resolve(module)
  })
}
const wholesaleView = (resolve) => {
import('@/components/purchase/wholesaleOrder/view').then((module) => {
    resolve(module)
  })
}
const wholesaleAdvanceView = (resolve) => {
  import('@/components/purchase/wholesaleAdvance/view').then((module) => {
    resolve(module)
  })
}
const wholesaleStlView = (resolve) => {
  import('@/components/purchase/wholesaleStl/view').then((module) => {
    resolve(module)
  })
}
const wholesaleList = (resolve) => {
  import('@/components/ccBox/wholesale/wholesaleList').then((module) => {
    resolve(module)
  })
}

const invoiceCheckView = (resolve) => {
  import('@/components/purchase/invoiceCheck/view').then((module) => {
    resolve(module)
  })
}
const purchaseBalanceView = (resolve) => {
  import('@/components/purchase/banlance/view').then((module) => {
    resolve(module)
  })
}
export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'login',
      component: login
    },
    {
      path: '/home',
      name: '首页',
      component: Index
    },
    {
      path: '/guide',
      name: '引导页',
      component: guide
    },
    {
      path: '/login',
      name: '登录',
      component: login
    },
    {
      path: '/register',
      name: '注册',
      component: register
    },
    {
      path: '/purchase/store/list',
      name: '门店申请列表',
      component: storeList
    },
    {
      path: '/purchase/store/view/:val',
      name: '门店申请单',
      component: auditView
    },
    {
      path: '/purchase/purchaseOrder/view/:val',
      name: '采购订单',
      component: purchaseOrderView
    },
    {
      path: '/purchase/advanceOrder/view/:val',
      name: '采购预付款申请单',
      component: advanceOrderView
    },
    {
      path: '/purchase/purchaseBack/view/:val',
      name: '采购退单',
      component: purchaseBackView
    },
    {
      path: '/ccBox/wholesale/wholesaleList',
      name: '批发列表',
      component: wholesaleList
    },
    {
      path: '/purchase/wholesaleOrder/view/:val',
      name: '批发订单详情',
      component: wholesaleView
    },
    {
      path: '/purchase/wholesaleAdvance/view/:val',
      name: '批发预收款详情',
      component: wholesaleAdvanceView
    },
    {
      path: '/purchase/wholesaleStl/view/:val',
      name: '批发其他结算详情',
      component: wholesaleStlView
    },

    {
      path: '/purchase/purchaseInvoice/view/:val',
      name: '发票核销申请单',
      component: invoiceCheckView
    },
    {
      path: '/purchase/paymentApply/view/:val',
      name: '付款结算单',
      component: purchaseBalanceView
    }
  ]
})

