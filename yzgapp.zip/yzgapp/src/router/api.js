import axios from 'axios'
import qs from 'qs'
let root = process.env.API_ROOT
import {loadUser} from 'assets/js/cache'
/*axios.interceptors.response.use((response) => {
  return response;
}, function (error) {
  if (401 === error.response.status) {
    window.location = '/login';
  } else {
    return Promise.reject(error);
  }
});*/
//axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';
export default {
  postform(url, data,success,error) {
    let userInfo = loadUser();
    return axios({
      method:'post',
      url:root+url,
      data: qs.stringify(data),
      headers : {
        'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8',
        "staff-id":userInfo.staffId,
        "company-id":userInfo.companyId
      }
    }).then(res => {
      success(res);
    }).catch(err => {
      error(err)
    })
  },
  post(url, data,success,error) {
    let userInfo = loadUser();
    return axios({
      method:'post',
      url:root+url,
      data: data,
      headers : {
        "staff-id":userInfo.staffId,
        "company-id":userInfo.companyId
      }
    }).then(res => {
      success(res);
    }).catch(err => {
      error(err)
    })
  },
  get(url,params,success,error) {
    let userInfo = loadUser();
    return axios({
      method:'get',
      url:root+url,
      params: params,
      headers : {
        'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8',
        "staff-id":userInfo.staffId,
        "company-id":userInfo.companyId
      }
    }).then(res => {
      success(res);
    }).catch(err => {
      error(err)
    })
  },
  all(urls,success,error){
    return axios.all(urls)
           .then(
             axios.spread(function () {
               let aReturn = []
               for (let i of arguments) {
                 aReturn.push(i)
               }
             success(aReturn);
             })
           ).catch(err => {
              error(err)
           });
  }
}
