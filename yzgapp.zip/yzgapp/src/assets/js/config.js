//审核详情路由
export const auditType = {
  1:'/purchaseBack/view',//采购退单
  2:'/store/view',//门店申请单
  3:'/rebateOrder/view',//返利单
  4:'/certainOrder/view',//价保单
  5:'/advanceOrder/view',//预付款申请单
  6:'/purchaseOrder/view',//采购订单
  7:'/wholesaleOrder/view',//批发订单
  8:'/wholesaleBackOrder/view',//批发退单
  9:'/paymentApply/view',//付款申请单
  10:'/paymentSettlement/view',//付款结算单
  11:'/receiptSettlement/view',//收款款结算单
  12:'/wholesaleVerification/view',//批发发票核销申请单
  13:'/wholesaleAdvance/view',//批发预收单
  14:'/purchaseInvoice/view',//采购发票核销申请单
  15:'/wholesaleCertain/view',//批发价保单
  16:'/wholesaleRebate/view',//批发返利单
  17:'/allotApply/view',//调拨申请单
  18:'/wholesaleStl/view',//批发其他结算单
  19:'/retailPrice/view',//零售价格调整单
  20:'/wholesalePrice/view',//批发价格调整单
};
//首页入口审核单据配置
export const entryOrderType = {
  purchase  : [1,2,5,6,9,14],
  wholesale : [7,8,12,13,18],
};
//api接口url
export const apiUrl = {
  global : {
    login        : '/staff/api/validate',//登录接口
    queryRefer   : '/api/purchase-refer/query-page-by-orderid',//查询参考信息
    saveRefer    : '/api/purchase-refer/save',//保存参考信息
    getAuditType : '/approve-notify/api/new/query-to-menu',//获取审核订单类型
    getMsg       : '/approve-notify/api/query-newest',//获取轮询信息
  },
  purchase : {
    approveList          : '/approve-notify/api/new/query-page-by-approved',//我已审核列表
    approveWillList      : '/approve-notify/api/new/query-page-by-will-approve',//待我审核列表
    storeDetail          : '/api/purchase-apply/query-page-by-my-approve',//门店采购申请单详情
    queryStoreSales      : '/retail/other/api/query-sales-by-prod-ids',//门店采购申请单-辅助参考-零售
    queryStoreStock      : '/stock-pool/api/findStockProductSumByCompanyIdAndProductIds',//门店采购申请单-辅助参考-库存
    queryCompanySales    : '/retail/other/api/query-company-2week-sales-by-prod-ids',//公司-零售
    queryCompanyStock    : '/stock-pool/api/findStockProductSumByCompanyIdAndProductIds',//公司-库存
    queryCompanyWhoesale : '/wholesale/api/order/sellNum',//公司-批发
    storeApprove         : '/api/purchase-apply/approve',//门店申请单-审核接口
    getApproveProcess    : '/api/workflow-process/list-by-orderId',//门店申请单-审核流程
    getPurchaseDetail    : '/api/purchase-order/query-page-by-my-apply',//获取采购订单详情
    purchaseApprove      : '/api/purchase-order/approve',//采购订单审核
    getAdvanceDetail     : '/advance/api/detail/',//采购订单审核
    advanceApprove       : '/advance/api/approve',//采购预付款--审核
    advanceReject        : '/advance/api/reject',//采购预付款--驳回
    getInvoiceDetail     : '/vendor-invoice/api/detail/',//发票核销申请单
    getBack              : '/purchase-back/query-page-by-my-apply',//采购退单详情
    backApprove          : '/purchase-back/approve',//采购退单审核
    paymentApply         : '/paymentApply/api/info/',//采购付款申请单-详情
    paymentApprove       : '/paymentApply/api/approve',//采购付款申请单-审核同意
    paymentApproveBack   : '/paymentApply/api/approve/back',//采购付款申请单-审核驳回
  }
};
//结算类型
export const settlemenType = {
  1 : '付款结算',
  2 : '其他结算',
};
export const settlemenMode = {
  1 : '返利结算',
  2 : '价保结算',
  3 : '预付款结算',
  4 : '承兑结算',
  5 : '转账结算',
  6 : '延期支票',
  7 : '微信',
  8 : '支付宝',
  9 : '现金',
  10 : '其它',
};
export const approveStatus = {
  0: {
    className : '',
      text: '发起流程'
  },
  1 : {
    className : 'status-will',
      text: '待审核'
  },
  2 : {
    className : 'status-pass',
      text: '审核通过'
  },
  4 : {
    className : 'status-reject',
      text: '驳回'
  },
  5 : {
    className : '',
      text: '已终止'
  }
};
