import storage from 'good-storage'

const SEARCH_KEY = '__user__'
const STATISTICS_KEY = '__statistics__'
const SEARCH_MAX_LEN = 15
function insertArray(arr, val, compare, maxLen) {
  const index = arr.findIndex(compare)
  if (index === 0) {
    return
  }
  if (index > 0) {
    arr.splice(index, 1)
  }
  arr.unshift(val)
  if (maxLen && arr.length > maxLen) {
    arr.pop()
  }
}

function deleteFromArray(arr, compare) {
  const index = arr.findIndex(compare)
  if (index > -1) {
    arr.splice(index, 1)
  }
}

export function saveUser(userInfo) {
  storage.set(SEARCH_KEY, userInfo)
  return userInfo
}
export function saveStatistics(statisticsInfo) {
  storage.set(STATISTICS_KEY, statisticsInfo)
  return statisticsInfo
}
export function deleteUser(query) {
  let searches = storage.get(SEARCH_KEY, [])
  /*deleteFromArray(searches, (item) => {
    return item === query
  })*/
  storage.set(SEARCH_KEY, searches)
  return searches
}

export function clearUser() {
  storage.remove(SEARCH_KEY)
  return []
}

export function loadUser() {
  return storage.get(SEARCH_KEY, [])
}
export function loadStatistics() {
  return storage.get(STATISTICS_KEY, [])
}
