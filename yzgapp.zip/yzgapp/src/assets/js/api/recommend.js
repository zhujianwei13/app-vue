import api from 'router/api'
import {apiUrl} from 'assets/js/config'
/*axios.interceptors.response.use((response) => {
  return response;
}, function (error) {
  if (401 === error.response.status) {
    window.location = '/login';
  } else {
    return Promise.reject(error);
  }
});
axios.defaults.headers.common['X-Requested-With'] = 'XMLHttpRequest';*/
//登录
export function login(params,success,error) {
  api.get(apiUrl.global.login,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//查询参考信息
export function queryRefer(params,success,error){
  const url = apiUrl.global.queryRefer
  api.postform(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//保存参考信息
export function saveRefer(params,success,error){
  const url = apiUrl.global.saveRefer
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//获取审核订单类型
export function getAuditType(params,success,error) {
  const url = apiUrl.global.getAuditType
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//轮询
export function getMsg(params,success,error){
  const url = apiUrl.global.getMsg
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}

