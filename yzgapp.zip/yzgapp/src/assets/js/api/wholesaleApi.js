/**
 * Created by zhangfuchuan on 2018/4/28.
 */
import api from "router/api";
//获取审核订单类型   TODO
export function getAuditType(params,success,error) {
  const url = '/approve-notify/api/query-to-menu'
  api.get(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//批发列表查询所有
export function getPfList(params, success, error) {
  var url = '/approve-notify/api/query-page-by-approved'

  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//批发审核查询所有
export function getPfSh(params,success,error) {
  var url = '/approve-notify/api/query-page-by-will-approve'
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}



//批发订单详情
export function getStoreDetail(params,success,error) {
  const url = '/wholesale/api/order/page'
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//批发订单审核--同意
export function storeApproveY(params,success,error) {
  const url = '/wholesale/api/order/audit'
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//批发订单审核--驳回
export function storeApproveN(params,success,error) {
  const url = '/wholesale/api/order/audit/back'
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//批发订单审核--流程
export function getApproveProcess(params,success,error) {
  const url ='/wholesale/api/order/audit/list'
  api.get(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}


//批发预收款单详情
export function getStoreDetailYsk(params,success,error) {
  const url = '/wholesale/api/advance/page'
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//批发预收款审核--同意
export function storeApproveYskY(params,success,error) {
  const url = '/wholesale/api/advance/audit'
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//批发预收款审核--驳回
export function storeApproveYskN(params,success,error) {
  const url = '/wholesale/api/advance/audit/back'
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//批发预收款审核--流程
export function getApproveProcessYsk(params,success,error) {
  const url ='/wholesale/api/advance/audit/list'
  api.get(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}


//批发其他申请单详情
export function getStoreDetailOther(params,success,error) {
  const url = '/wholesale/api/settlement/page'
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//批发其他申请单审核--同意
export function storeApproveOtherY(params,success,error) {
  const url = '/wholesale/api/settlement/audit'
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//批发其他申请单审核--驳回
export function storeApproveOtherN(params,success,error) {
  const url = '/wholesale/api/settlement/audit/back'
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//批发其他申请单审核--流程
export function getApproveProcessOther(params,success,error) {
  const url ='/wholesale/api/settlement/audit/list'
  api.get(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
