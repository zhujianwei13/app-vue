import api from "router/api";
import {apiUrl} from 'assets/js/config'
//获取审核列表
export function getApproved(params, success, error) {
  const url = apiUrl.purchase.approveList
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
export function getApprovedWill(params,success,error) {
  const url = apiUrl.purchase.approveWillList
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//获取门店采购申请单详情
export function getStoreDetail(params,success,error) {
  const url = apiUrl.purchase.storeDetail
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//门店采购申请单-辅助参考-零售
export function queryStoreSales(params,success,error) {
  const url = apiUrl.purchase.queryStoreSales
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//门店采购申请单-辅助参考-库存
export function queryStoreStock(params,success,error) {
  const url = apiUrl.purchase.queryStoreStock
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//公司-零售
export function queryCompanySales(params,success,error) {
  const url = apiUrl.purchase.queryCompanySales
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//公司-库存
export function queryCompanyStock(params,success,error) {
  const url = apiUrl.purchase.queryCompanyStock
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//公司-批发
export function queryCompanyWhoesale(params,success,error) {
  const url = apiUrl.purchase.queryCompanyWhoesale
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//门店申请单-审核接口
export function storeApprove(params,success,error) {
  const url = apiUrl.purchase.storeApprove
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//门店申请单-审核流程
export function getApproveProcess(params,success,error) {
  const url = apiUrl.purchase.getApproveProcess
  api.postform(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//获取采购订单详情
export function getPurchaseDetail(params,success,error) {
  const url = apiUrl.purchase.getPurchaseDetail
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//采购订单审核
export function purchaseApprove(params,success,error) {
  const url = apiUrl.purchase.purchaseApprove
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//采购预付款详情
export function getAdvanceDetail(params,success,error) {
  const url = apiUrl.purchase.getAdvanceDetail+params.advanceId
  api.get(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//采购预付款--审核
export function advanceApprove(params,success,error){
  const url = apiUrl.purchase.advanceApprove
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//采购预付款--驳回
export function advanceReject(params,success,error){
  const url = apiUrl.purchase.advanceReject
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//发票核销申请单
export function getInvoiceDetail(params,success,error){
  const url = apiUrl.purchase.getInvoiceDetail+params.id
  api.get(url,'',function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//采购退单详情
export function getPuchaseBack(params,success,error){
  const url = apiUrl.purchase.getBack
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//采购退单审核
export function puchaseBackApprove(params,success,error){
  const url = apiUrl.purchase.backApprove
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//采购付款申请单-详情
export function paymentApply(params,success,error){
  const url = apiUrl.purchase.paymentApply+params.paymentApplyId
  api.get(url,'',function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//采购付款申请单-审核
export function paymentApprove(params,success,error){
  const url = apiUrl.purchase.paymentApprove
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
//采购付款申请单-驳回
export function paymentApproveBack(params,success,error){
  const url = apiUrl.purchase.paymentApproveBack
  api.post(url,params,function (res) {
    success(res);
  },function (err) {
    error(err);
  })
}
