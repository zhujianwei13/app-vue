<!-- 首页 -->
<template>
  <vue-drawer-layout
    ref="drawer"
    :drawer-width="100"
    :z-index="0"
    :backdrop="false"
    :drawable-distance="Math.floor(100/3)"
    :content-drawable="true">
    <div class="menu-content" slot="drawer" style="position: relative">
      <div class="user-info">
        <img class="" :src="avator" >
        <p>{{userHistory.staffName}}</p>
      </div>
      <!-- drawer-content -->
      <router-link :to="{path:'./login'}">
        <button class="quit-btn"><i class="icon iconfont icon-web-icon-"></i>退出</button>
      </router-link>

    </div>
    <div slot="content">
      <div>
        <div class="index-header">
          <img class="index-logo" :src="logo"/>
          <div class="mask"></div>
        </div>
        <div class="index-gap"></div>
        <div class="index-main">
          <div class="index-item">
            <div class="index-title">
              <i class="left-line"></i>
              <span>审核单据</span>
            </div>
            <ul>
              <li>
                <div>
                  <router-link :to="{path:'./purchase/store/list', query:{entryType:'purchase'}}">
                    <i class="icon-index icon-purchase"></i>
                  </router-link>
                  <p>采购单据</p>
                </div>
              </li>
              <li>
                <div>
                  <router-link :to="{path:'./purchase/store/list', query:{entryType:'wholesale'}}">
                    <i class="icon-index icon-pf"></i>
                    <p>批发单据</p>
                  </router-link>
                </div>
              </li>
              <li>
                <div>
                  <router-link :to="{path:'./forhidden'}">
                    <i class="icon-index icon-lend"></i>
                    <p>调借单据</p>
                  </router-link>
                </div>
              </li>
              <li>
                <div>
                  <router-link :to="{path:'./forbidden'}">
                    <i class="icon-index icon-price"></i>
                    <p>价保返利</p>
                  </router-link>
                </div>
              </li>
              <li>
                <div>
                  <router-link :to="{path:'./forbidden'}">
                    <i class="icon-index icon-price-change"></i>
                    <p>价格调整</p>
                  </router-link>
                </div>
              </li>
            </ul>
          </div><!--index-item-->
          <div class="index-item">
            <div class="index-title">
              <i class="left-line"></i>
              <span>零售统计分析</span>
            </div>
            <ul>
              <li>
                <div>
                  <router-link :to="{path:'./forbidden'}">
                  <i class="icon-index icon-ls-1"></i>
                  <p>零售统计</p>
                  </router-link>
                </div>
              </li>
              <li>
                <div>
                  <router-link :to="{path:'./forbidden'}">
                  <i class="icon-index icon-ls-2"></i>
                  <p>商品分析</p>
                  </router-link>
                </div>
              </li>
              <li>
                <div>
                  <router-link :to="{path:'./forbidden'}">
                  <i class="icon-index icon-ls-3"></i>
                  <p>结算分析</p>
                  </router-link>
                </div>
              </li>
            </ul>
          </div><!--index-item-->
          <div class="index-item">
            <div class="index-title">
              <i class="left-line"></i>
              <span>批发统计分析</span>
            </div>
            <ul>
              <li>
                <div>
                  <router-link :to="{path:'./forbidden'}">
                  <i class="icon-index icon-pf-1"></i>
                  <p>批发统计</p>
                  </router-link>
                </div>
              </li>
              <li>
                <div>
                  <router-link :to="{path:'./forbidden'}">
                  <i class="icon-index icon-pf-2"></i>
                  <p>商品分析</p>
                  </router-link>
                </div>
              </li>
              <li>
                <div>
                  <router-link :to="{path:'./forbidden'}">
                  <i class="icon-index icon-pf-3"></i>
                  <p>客户分析</p>
                  </router-link>
                </div>
              </li>
            </ul>
          </div><!--index-item-->
          <div class="index-item">
            <div class="index-title">
              <i class="left-line"></i>
              <span>采购统计分析</span>
            </div>
            <ul>
              <li>
                <div>
                  <router-link :to="{path:'./forbidden'}">
                  <i class="icon-index icon-pf-1"></i>
                  <p>采购统计</p>
                  </router-link>
                </div>
              </li>
              <li>
                <div>
                  <router-link :to="{path:'./forbidden'}">
                  <i class="icon-index icon-pf-2"></i>
                  <p>商品分析</p>
                  </router-link>
                </div>
              </li>
              <li>
              </li>
            </ul>
          </div><!--index-item-->
        </div>
      </div>
    </div>
  </vue-drawer-layout>

</template>
<script>
  import logo from './img/logo.png'
  import avator from 'assets/avator.png'
  import {getMsg} from 'assets/js/api/recommend'
  import {mapGetters} from 'vuex'
  import {mapActions} from 'vuex'
export default {
  components: {
  },
  data () {
    return {
      logo: logo,
      avator: avator
    }
  },
  props: {},
  watch: {},
  methods: {
    judgePlatform() {
      switch ( plus.os.name ) {
        case "Android":
          alert('Android')
          // Android平台: plus.android.*
          break;
        case "iOS":
          alert('iOS')
          // iOS平台: plus.ios.*
          break;
        default:
          // 其它平台
          break;
      }
    }
  },
  filters: {},
  computed: {
    ...mapGetters([
      'userHistory',
      'statisticsRecord'
    ]),
    ...mapActions([
      'saveStatisticsRecord'
    ])
  },
  created () {
    let params = {
      companyId : this.userHistory.companyId,
      limit : 10,
      offset : 0,
      staffId : this.userHistory.staffId,
      startTime : new Date(),
    },_this = this;
    /*setInterval(()=>{
      getMsg(params,function (res) {
        if(res.data.retStatus === 0){
          _this.saveStatisticsRecord(res.data.retData);
        }
      },function (error) {

      })
    },1000);*/
  },
  mounted () {
  },
  destroyed () {}
}
</script>

<style lang="scss" scoped>
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  @import './icon.css';
  .quit-btn{
    position: absolute;
    bottom: 1.57rem;
    left: 0;
    font-size: $font-size-medium;
    color: $color-left-slide-text;
    border: none;
    padding: 0;
    width: 100%;
    .icon{
      vertical-align: middle;
      font-size: $font-size-18;
      color: $color-left-slide-text !important;
      font-weight: bold;
    }
  }
  .index-header{
    position: relative;
    height:2.048rem;
    background:url("./img/indexbg.png") center center no-repeat;
    background-size: cover;
    .index-logo{
      position: absolute;
      left: 50%;
      margin-left: -1.066rem;
      top: 50%;
      margin-top: -0.4rem;
      width:2.13rem;
      z-index: 1;
    }
    .mask{
      position: absolute;
      width: 100%;
      height: 100%;
      background: rgba(0,0,0,0.38);
    }
  }
  .index-gap{
    height:$gap;
    background-color: #efedec;
  }
  .index-main{
    .index-title{
      position: relative;
      height: 0.906rem;
      line-height: 0.906rem;
      text-align: left;
      padding-left: 0.533rem;
      span{
        font-size: $font-size-medium;
        color: $color-text-index-title;
      }
      .left-line{
        position: absolute;
        top: 0.128rem;
        left: -0.068rem;
        width: 0.1365rem;
        border-radius: 0.068rem;
        height: 0.716rem;
        background-color: $color-text-green;
      }
    }
    ul{
      display: flex;
      margin-top: 0.426rem;
      padding-bottom: 0.64rem;
      li{
        display: flex;
        flex: 1;
        justify-content: center;
        p{
          margin-top: 0.32rem;
          font-size: $font-size-12;
          color: $color-text-index-title;
          line-height: 1;
        }
      }
    }
  }
  /deep/ .menu-content{
    padding: 0;
    height: 100%;
  }
  .user-info{
    padding-top: 1.70rem;
    img{
      width: 1rem;
    }
    p{
      line-height: 1;
      margin-top: 0.2rem;
      font-size: $font-size-medium;
      color: $color-text-index-title;
    }
  }
  /deep/ .content-wrap{
    background-color: #fff;
  }
</style>
