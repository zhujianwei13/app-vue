<template>
  <div class="container padding-sh-list">
    <ysl-header :title = 'title'></ysl-header>
    <audit-tab :type = 'type' :loadMore="loadMore" :loadwillMore="loadwillMore" @selected="changeApprove($event)" :pageSize="pageSize" :expireNumber="expireNumber"></audit-tab>
    <search-tab @changeType="changeType($event)" :resultNum="type" :typeList="typeList"></search-tab>
  </div>
</template>

<script type="text/ecmascript-6">
  import yslHeader from '@/components/base/header/header'
  import auditTab from '@/components/base/audit/audit-tab'
  import searchTab from '@/components/base/audit/search'
  import {mapGetters} from 'vuex'
  import {getPfList,getPfSh,getAuditType} from 'assets/js/api/wholesaleApi'
  export default {
    components: {
      yslHeader,
      auditTab,
      searchTab
    },
    data () {
      return {
        title : '批发列表',
        type : 0,
        pageIndex: 0,
        pagewillIndex: 0,
        pageSize: 10,
        close : false,
        selected : 1,
        expireNumber: 0,
        typeList: []
      }
    },
    methods: {
      changeType (type) {
        this.type = type;
        console.log(type);
      },
      changeApprove (val) {
        this.selected = val;
      },
      loadMore (cb) {
        let _this = this;
        let param = {
          companyId: this.userHistory.companyId,
          staffId: this.userHistory.staffId,
          limit: this.pageSize,
          orderType: this.type===0?'':this.type,
          offset: this.pageIndex*this.pageSize
        }

        getPfList(param,function (res) {
          if(res.data.retStatus === 1){
            Toast(res.data.retDesc);
            return;
          }
          _this.expireNumber = res.data.total;
          cb(res.data.rows);
          _this.pageIndex ++;

        },function (err) {

        });
      },
      loadwillMore (cb) {
        let _this = this;
        let param = {
          companyId: this.userHistory.companyId,
          staffId: this.userHistory.staffId,
          orderType: this.type===0?'':this.type,
          limit: this.pageSize,
          offset: this.pagewillIndex*this.pageSize
        }
        getPfSh(param,function (res) {
          if(res.data.retStatus === 1){
            Toast(res.data.retDesc);
            return;
          }
          _this.expireNumber = res.data.total;
          cb(res.data.rows);
          _this.pagewillIndex ++;

        },function (err) {

        });
      }
    },
    filters: {},
    method: {

    },
    computed: {
      ...mapGetters(['userHistory'])
  },
  created () {},
  watch: {
    type (){
      this.pageIndex = 0;
      this.pagewillIndex = 0;
    },
    selected () {
      this.pageIndex = 0;
      this.pagewillIndex = 0;
    }
  },
  mounted () {
    let _this = this;
    let param = {
      staffId: this.userHistory.staffId,
      companyId: this.userHistory.companyId
    };
    getAuditType(param,function (res) {
      let _data  = res.data.retData;
      _this.typeList = _data;
    },function (err) {

    });
  },
  destroyed () {}
  }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
</style>
