<!-- 注册 组件 -->

<template>
  <div class="login">
      <img class="logo" :src="logo"/>
      <!-- 第一步 -->
      <mt-tab-container-item class="login-wrapper">
        <mt-field placeholder="您的公司/店面" v-model="company"></mt-field>
        <mt-field placeholder="您所在的区域" v-model="address"></mt-field>
        <mt-field placeholder="您的姓名" v-model="username"></mt-field>
        <mt-field placeholder="您的电话" v-model="phone"></mt-field>
        <mt-field placeholder="您获知的途径" v-model="method" @click.native="methodPop"></mt-field>
        <mt-popup v-model="popupVisible" position="bottom">
          <mt-picker :slots="slots" @change="onValuesChange"></mt-picker>
        </mt-popup>
        <mt-button type="default" size="large" @click.native="apply">提交申请</mt-button>
      </mt-tab-container-item>
  </div>
</template>

<script>
  import logo from '../login/img/login-logo.png'
  export default {
    components: {
    },
    data () {
      return {
        slots: [
          {
            flex: 1,
            values: ['2015-01', '2015-02', '2015-03', '2015-04', '2015-05', '2015-06'],
            className: 'slot1',
            textAlign: 'center'
          }
        ],
        company: '',
        address: '',
        username: '',
        popupVisible: false,
        method: '',
        logo: logo,
        phone: '',
        flag: 0
      }
    },
    props: {},
    watch: {},
    methods: {
      back () {
        this.$router.push({
          path: '/index'
        })
      },
      methodPop () {
        this.flag = 1;
        this.popupVisible = true
      },
      onValuesChange (picker, values) {
        console.log(values)
        if(this.flag != 0){
          this.method = values[0];
          console.log(values[0]);
        }

      },
      apply () {

      }
    },
    filters: {},
    computed: {},
    created () {},
    mounted () {}
  }
</script>

<style lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .logo{
    width: 3.49rem;
    margin-top: 3.09rem;
  }
  .login {
    color: #333;
    background-color: #fff;
    overflow: visible;
    padding: 0 1.813rem;
    .login-wrapper {
      overflow: hidden;
      margin-top: 1.518rem;
      .mint-button {

      }
      .mint-cell{
        min-height: auto;
        margin-bottom:0.773rem;
      }
    }
    .register-wrapper {
      margin-top: 20px;
      overflow: hidden;
      .mint-button {
        margin-top: 30px;
      }
    }
  }

</style>
