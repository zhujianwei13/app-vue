<template>
  <div>
    <ysl-header :title = 'audit.orderTypeName'></ysl-header>
    <audit-header :avator="avator" :orderTypeName="audit.orderTypeName" :selectType="selectType"></audit-header>
    <div class="audit-view" v-if="detailInfo">
      <audit-proccess :getProcess="getProccess"></audit-proccess>
      <div class="module-item">
        <div class="module-header" :class="{'isSpread' : false}">
          <span>基础信息</span>
        </div>
        <div class="module-main">
          <p class="p-base"><label>单据号</label>{{detailInfo.purchaseBackNo}}</p>
          <p class="p-base"><label>退单单位</label>{{detailInfo.orgName}}</p>
          <p class="p-base"><label>制单人</label>{{detailInfo.staffName}}</p>
          <p class="p-base"><label>制单日期</label>{{detailInfo.addTime | formatDate}}</p>
        </div>
      </div>
      <div class="module-item">
        <div class="module-header" :class="{'isSpread' : false}">
          <span>供应商信息</span>
        </div>
        <div class="module-main">
          <p class="p-base"><label>供应商</label>{{detailInfo.vendorName}}</p>
          <p class="p-base"><label>退单原因</label>{{detailInfo.backReasonName}}</p>
          <p class="p-base"><label>退单类型</label>{{detailInfo.backTypeName}}</p>
        </div>
      </div>
      <div class="module-item">
        <div class="module-header">
          <span>退单信息</span>
        </div>
        <div class="module-main">
          <div class="backOrder-info border-dash" v-for="item in detailInfo.detailVOs">
            <div v-for="(backInfo,index) in item.detailVOs">
              <div v-if="index === 0">
                <p class="p-base"><label>采购单号</label><span class="text-yellow">{{backInfo.purchaseOrderNo}}</span></p>
                <p class="p-base"><label>发票类型</label><span class="text-yellow">{{backInfo.invoiceTypeName}}</span></p>
                <p class="p-base"><label>退款方式</label><span class="text-yellow">{{backInfo.backMoneyTypeName}}</span></p>
                <p class="p-base"><label>退票方式</label>{{backInfo.backInvoiceTypeName}}</p>
                <div class="p-base p-textarea">
                  <label>明细备注</label>
                  <div class="textarea-detail"><p>{{backInfo.remark || '-'}}</p></div>
                </div>
              </div>
              <p class="p-base p-title mt20">{{backInfo.productName}}</p>
              <p class="p-base"><label>采购单价</label>{{backInfo.purchaseOrderPrice}}</p>
              <p class="p-base"><label>采购数量</label>{{backInfo.purchaseOrderNum}}</p>
              <p class="p-base"><label>退货单价</label><span class="text-yellow">{{backInfo.purchaseBackPrice}}</span></p>
              <p class="p-base"><label>退货数量</label><span class="text-yellow">{{backInfo.purchaseBackNum}}</span></p>
              <p class="p-base"><label>退货总价</label><span class="text-yellow">{{backInfo.purchaseBackPrice*backInfo.purchaseBackNum}}</span></p>
            </div>
          </div>
        </div>
      </div><!--moudle-item-->
      <div class="module-item">
        <div class="module-header">
          <span>退货信息</span>
        </div>
        <div class="module-main">
          <p class="p-base"><label>退回地址</label>{{detailInfo.vendorAddress}}</p>
          <p class="p-base"><label>收货人</label>{{detailInfo.vendorEmpName}}</p>
          <p class="p-base"><label>联系电话</label>{{detailInfo.vendorEmpPhone}}</p>
        </div>
      </div><!--moudle-item-->
      <div class="module-item">
        <div class="module-header">
          <span>单据备注</span>
        </div>
        <div class="module-main">
          <p class="p-base">{{detailInfo.remark || '暂无备注'}}</p>
        </div>
      </div>
      <div class="module-item" v-if="selectType === 1">
        <div class="module-header header-yellow">
          <span>审核备注</span>
        </div>
        <div class="module-main">
          <div class="audit-remark">
            <i class="icon iconfont icon-wenbenbianji"></i>
            <input type="text" v-model="remark" placeholder="（非必填）写备注..."/>
          </div>
        </div>
      </div>
    </div><!--audit-view-->
    <div class="audit-foot" v-if="selectType === 1">
      <button @click="submit('2')" type="submit" class="green">同意</button>
      <button @click="submit('4')" type="submit" class="reject">驳回</button>
      <button class="remark">备注</button>
    </div>
  </div>
</template>

<script>
  import yslHeader from '@/components/base/header/header'
  import {mapGetters} from 'vuex'
  import {getPuchaseBack,puchaseBackApprove,getApproveProcess} from 'assets/js/api/purchase'
  import auditProccess from '@/components/base/audit/audit-proccess'
  import auditHeader from '@/components/base/audit/audit-header'
  import { Toast } from 'mint-ui'
  import {mapToArray} from 'assets/js/util'
  import avator from '../../../assets/avator.png'
  export default {
    components: {
      yslHeader,
      auditProccess,
      auditHeader
    },
    data () {
      return {
        val : '',
        text : '',
        remark : '',
        entryType : '',
        selectType: 1,
        avator : avator,
        sequence : false,
        detailInfo: {}
      }
    },
    created() {
      this.entryType = this.$route.query.entryType
    },
    methods: {
      show (type) {
        switch (type){
          case 'sequence':
            this.sequence = !this.sequence;
            break;
          case 'assist':
            this.assist = !this.assist;
            break;
          case 'product':
            this.product = !this.product;
            break;
          case 'additional':
            this.additional = !this.additional;
            break;
        }
      },
      getProccess (success) {
        let param = {
          orderId: this.audit.orderId
        };
        getApproveProcess(param,function (res) {
          if(res.data.retStatus != 1){
            success(res.data);
          }
        },function (err) {

        });
      },
      backOrderGroup (detailVOs) {
        let mapSummary = {};
        for(let i =0;i<detailVOs.length;i++){
          let backSummary = {};
          let backDetailVO = detailVOs[i];
          backSummary.purchaseOrderSummaryId = backDetailVO.purchaseOrderSummaryId;
          if(mapSummary.hasOwnProperty(backSummary.purchaseOrderSummaryId)){
            (mapSummary[backSummary.purchaseOrderSummaryId].detailVOs).push(backDetailVO);
          }else{
            mapSummary[backSummary.purchaseOrderSummaryId] = backSummary;
            backSummary.detailVOs = [backDetailVO];
          }
        }
        let backSummarys = mapToArray(mapSummary);
        this.detailInfo.detailVOs = backSummarys;
      },
      _getPurchaseDetail () {
        let params = {
          companyId: this.userHistory.companyId,
          purchaseBackNo: this.audit.orderNo,
          "offset":0,
          "limit":1
        },_this = this;
        getPuchaseBack(params,function (res) {
          if(res.data.retStatus === 1){
            Toast(res.data.retDesc);
            return;
          }
          _this.detailInfo = res.data.rows[0];
          _this.backOrderGroup(_this.detailInfo.detailVOs);
        },function (err) {
          Toast(err.message);
        });
      },
      submit(type){
        let _this = this,
          params = {
            orderId : _this.audit.orderId,
            staffId : _this.userHistory.staffId,
            companyId : _this.userHistory.companyId,
            status : type,
            comment : _this.remark,
          };
        puchaseBackApprove(params,function (res) {
          if(res.data.retStatus === 0){
            Toast({
              message: '审核成功',
              duration: 1000
            });
            _this.$router.push({
              path: '/purchase/store/list',
              query:{entryType:_this.entryType}
            })
          }
          if(res.data.retStatus === 1){
            Toast({
              message: res.data.retDesc,
              duration: 1000
            });
          }
        },function (err) {

        });
      }
    },
    mounted() {
      this._getPurchaseDetail ()
      this.selectType = this.audit.selectId
    },
    computed: {
      ...mapGetters([
        'audit',
        'userHistory'
      ])
    }
  }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .slide-enter-active, .slide-leave-active{
    transition: all 0.3s
  }
  .slide-enter, .slide-leave-to{
    transform: translate3d(100%, 0, 0)
  }
  .slide-fade-enter-active {
    transition: all .3s ease;
  }
  .slide-fade-leave-active {
    transition: all .3s ease;
  }
  .slide-fade-enter, .slide-fade-leave-to
    /* .slide-fade-leave-active for below version 2.1.8 */ {
    transform: translateY(10px);
    opacity: 0;
  }
  .help{
    position: absolute;
    right: 0;
    top: 1.43rem;
    color: red;
  }
</style>
