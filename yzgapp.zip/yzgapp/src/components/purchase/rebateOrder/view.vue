<template>
  <div>
    <ysl-header :title = 'audit.orderTypeName'></ysl-header>
    <div class="audit-view-header">
      <img class="avator" :src="avator"/>
      <div class="orderDetail">
        <div>
          <h3>{{audit.orderTypeName}}</h3>
          <p>{{audit.statusName}}</p>
        </div>
      </div>
    </div>
    <div class="audit-view">
      <audit-proccess :orderId="audit.orderId"></audit-proccess>
      <div class="module-item">
        <div class="module-header" :class="{'isSpread' : false}">
          <span>基础信息</span>
        </div>
        <div class="module-main">
          <p class="p-base"><label>单据号</label>20180330CGSQ123654789556412</p>
          <p class="p-base"><label>采购单位</label>鼓楼紫峰门店</p>
          <p class="p-base"><label>制单人</label>刘钟毅</p>
          <p class="p-base"><label>制单日期</label>2018.03.30 12:11:35</p>
        </div>
      </div>
      <div class="module-item">
        <div class="module-header" :class="{'isSpread' : false}">
          <span>供应商信息</span>
        </div>
        <div class="module-main">
          <p class="p-base"><label>供应商</label>20180330CGSQ123654789556412</p>
          <p class="p-base"><label>返利类型</label>鼓楼紫峰门店</p>
          <p class="p-base"><label>使用方式</label>鼓楼紫峰门店</p>
        </div>
      </div>
      <div class="module-item">
        <div class="module-header">
          <span>商品返利信息</span>
        </div>
        <div class="order-title p-base p-title isSpread" @click="show('product')">
          <label>返利合计</label><span class="text-yellow">50000.00</span>
          <i class="icon iconfont icon-xialajiantou"></i>
        </div>
        <div class="module-main" v-show="product">
          <div class="product-info">
            <p class="p-base"><label>采购单号</label>qqqqqq</p>
            <p class="p-base p-title">iPhone 8 Plsu 6G 64G 全网通 星空灰 合约机</p>
            <p class="p-base"><label>采购单价</label>200</p>
            <p class="p-base"><label>采购数量</label>100</p>
            <p class="p-base"><label>采购总价</label>100</p>
            <p class="p-base"><label>返利单价</label><span class="text-yellow">200</span></p>
            <p class="p-base"><label>返利数量</label><span class="text-yellow">100</span></p>
            <p class="p-base"><label>返利总价</label><span class="text-yellow">100</span></p>
            <div class="moudle-table">
              <div class="table-cell table-left w34">
                <h3>返利单位</h3>
              </div>
              <div class="table-cell table-middle">
                <h3>返利单价</h3>
              </div>
              <div class="table-cell table-middle">
                <h3>返利台数</h3>
              </div>
              <div class="table-cell table-middle">
                <h3>返利总价</h3>
              </div>
            </div>
            <div class="moudle-table">
              <div class="table-cell table-left w34">
                <p>新街口门店</p>
              </div>
              <div class="table-cell table-middle">
                <p>10</p>
              </div>
              <div class="table-cell table-middle">
                <p>dddd</p>
              </div>
              <div class="table-cell table-middle">
                <p>dddd</p>
              </div>
            </div>
            <div class="p-base p-textarea">
              <label>明细备注</label>
              <div class="textarea-detail">备注备注</div>
            </div>
          </div>
        </div>
      </div><!--moudle-item-->
      <div class="module-item">
        <div class="module-header" :class="{'isSpread' : false}">
          <span>单据备注</span>
        </div>
        <div class="module-main">
          <p class="p-base">畅销机型</p>
        </div>
      </div>
      <div class="module-item">
        <div class="module-header header-yellow" :class="{'isSpread' : false}">
          <span>审核备注</span>
        </div>
        <div class="module-main">
          <div class="audit-remark">
            <input type="text" placeholder="（非必填）写备注..."/>
          </div>
        </div>
      </div>
    </div><!--audit-view-->
    <div class="audit-foot">
      <button class="green">同意</button>
      <button class="reject">驳回</button>
      <button class="remark">备注</button>
    </div>
  </div>
</template>

<script>
  import yslHeader from '@/components/base/header/header'
  import {mapGetters} from 'vuex'
  import auditProccess from '@/components/base/audit/audit-proccess'
  import avator from '../../../assets/avator.png'
  export default {
    components: {
      yslHeader,
      auditProccess
    },
    data () {
      return {
        val : '',
        text : '',
        avator : avator,
        sequence : false,
        assist : false,
        product : false,
        additional : false
      }
    },
    methods: {
      show (type) {
        switch (type){
          case 'sequence':
            this.sequence = !this.sequence;
            break;
          case 'assist':
            this.assist = !this.assist;
            break;
          case 'product':
            this.product = !this.product;
            break;
          case 'additional':
            this.additional = !this.additional;
            break;
        }

      }
    },
    mounted() {
    },
    computed: {
      ...mapGetters([
        'audit'
      ])
    }
  }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .slide-enter-active, .slide-leave-active{
    transition: all 0.3s
  }
  .slide-enter, .slide-leave-to{
    transform: translate3d(100%, 0, 0)
  }
  .slide-fade-enter-active {
    transition: all .3s ease;
  }
  .slide-fade-leave-active {
    transition: all .3s ease;
  }
  .slide-fade-enter, .slide-fade-leave-to
    /* .slide-fade-leave-active for below version 2.1.8 */ {
    transform: translateY(10px);
    opacity: 0;
  }
  .help{
    position: absolute;
    right: 0;
    top: 1.43rem;
    color: red;
  }
</style>
