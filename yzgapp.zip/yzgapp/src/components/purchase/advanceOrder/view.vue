<template>
  <div>
    <ysl-header :title = 'audit.orderTypeName'></ysl-header>
    <audit-header :avator="avator" :orderTypeName="audit.orderTypeName" :selectType="selectType"></audit-header>
    <div class="audit-view" v-if="detailInfo">
      <audit-proccess :getProcess="getProccess"></audit-proccess>
      <div class="module-item">
        <div class="module-header">
          <span>基础信息</span>
        </div>
        <div class="module-main">
          <p class="p-base"><label>单据号</label>{{detailInfo.advanceId}}</p>
          <p class="p-base"><label>采购单位</label>{{detailInfo.orgName}}</p>
          <p class="p-base"><label>制单人</label>{{detailInfo.staffName}}</p>
          <p class="p-base"><label>制单日期</label>{{detailInfo.addTime | formatDate}}</p>
        </div>
      </div>
      <div class="module-item">
        <div class="module-header" :class="{'isSpread' : false}">
          <span>供应商信息</span>
        </div>
        <div class="module-main">
          <p class="p-base"><label>供应商</label>{{detailInfo.vendorName}}</p>
          <p class="p-base"><label>账户</label>{{detailInfo.depositAccount}}</p>
          <p class="p-base"><label>付款方式</label>{{detailInfo.settlementModeDesc}}</p>
          <p class="p-base"><label>预付款金额</label><span class="text-yellow">{{detailInfo.totalAmount}}</span></p>
        </div>
      </div>
      <div class="module-item">
        <div class="module-header">
          <span>商品信息</span>
        </div>
        <div class="module-main">
          <div class="product-info" v-for="item in detailInfo.detailList">
            <p class="p-base p-title">{{item.productName}}</p>
            <p class="p-base"><label>采购数量</label><span class="text-yellow">{{item.purchaseNum}}</span></p>
            <div class="p-base p-textarea">
              <label>明细备注</label>
              <div class="textarea-detail"><p>{{item.remark || '-'}}</p></div>
            </div>
          </div>
        </div>
      </div><!--moudle-item-->
      <div class="module-item">
        <div class="module-header" :class="{'isSpread' : false}">
          <span>单据备注</span>
        </div>
        <div class="module-main">
          <p class="p-base">{{detailInfo.remark || '暂无备注'}}</p>
        </div>
      </div>
      <div class="module-item" v-if="selectType === 1">
        <div class="module-header header-yellow" :class="{'isSpread' : false}">
          <span>审核备注</span>
        </div>
        <div class="module-main">
          <div class="audit-remark">
            <i class="icon iconfont icon-wenbenbianji"></i>
            <input type="text" v-model="remark" placeholder="（非必填）写备注..."/>
          </div>
        </div>
      </div>
    </div><!--audit-view-->
    <div class="audit-foot" v-if="selectType === 1">
      <button @click="submit(2)" type="submit" class="green">同意</button>
      <button @click="submit(4)" type="submit" class="reject">驳回</button>
      <button class="remark">备注</button>
    </div>
  </div>
</template>

<script>
  import yslHeader from '@/components/base/header/header'
  import {mapGetters} from 'vuex'
  import {getAdvanceDetail,advanceApprove,getApproveProcess,advanceReject} from 'assets/js/api/purchase'
  import auditProccess from '@/components/base/audit/audit-proccess'
  import auditHeader from '@/components/base/audit/audit-header'
  import { Toast } from 'mint-ui'
  import avator from '../../../assets/avator.png'
  export default {
    components: {
      yslHeader,
      auditProccess,
      auditHeader
    },
    data () {
      return {
        val : '',
        entryType : '',
        text : '',
        avator : avator,
        sequence : false,
        assist : false,
        product : false,
        remark : '',
        detailInfo : {},
        selectType: 1,
        additional : false
      }
    },
    methods: {
      show (type) {
        switch (type){
          case 'sequence':
            this.sequence = !this.sequence;
            break;
          case 'assist':
            this.assist = !this.assist;
            break;
          case 'product':
            this.product = !this.product;
            break;
          case 'additional':
            this.additional = !this.additional;
            break;
        }
      },
      getProccess (success) {
        let param = {
          orderId: this.audit.orderId
        };
        getApproveProcess(param,function (res) {
          if(res.data.retStatus != 1){
            success(res.data);
          }
        },function (err) {

        });
      },
      _getPurchaseDetail () {
        let params = {
          advanceId: this.audit.orderId
        },_this = this;
        getAdvanceDetail(params,function (res) {
          if(res.data.retStatus === 1){
            Toast(res.data.retDesc);
            return;
          }
          _this.detailInfo = res.data.retData;
          console.log(_this.detailInfo)
        },function (err) {
          Toast(err.message);
        });
      },
      submit(type){
        let _this = this,
          params = {
            billId : _this.audit.orderId,
            approveStaffId : _this.userHistory.staffId,
            companyId : _this.userHistory.companyId,
            comment : _this.remark,
          };
        if(type === 2){
          advanceApprove(params,function (res) {
            if(res.data.retStatus === 0){
              Toast({
                message: '审核成功',
                duration: 1000
              });
              _this.$router.push({
                path: '/purchase/store/list',
                query:{entryType:_this.entryType}
              })
            }
            if(res.data.retStatus === 1){
              Toast({
                message: res.data.retDesc,
                duration: 1000
              });
            }
          },function (err) {

          });
        }
        if(type === 4){
          advanceReject(params,function (res) {
            if(res.data.retStatus === 0){
              Toast({
                message: '驳回成功',
                duration: 1000
              });
              _this.$router.push({
                path: '/purchase/store/list'
              })
            }
            if(res.data.retStatus === 1){
              Toast({
                message: res.data.retDesc,
                duration: 1000
              });
            }
          },function (err) {

          });
        }

      }
    },
    mounted() {
      this._getPurchaseDetail()
      this.selectType = this.audit.selectId
    },
    created() {
      this.entryType = this.$route.query.entryType
    },
    computed: {
      ...mapGetters([
        'audit',
        'userHistory'
      ])
    }
  }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .slide-enter-active, .slide-leave-active{
    transition: all 0.3s
  }
  .slide-enter, .slide-leave-to{
    transform: translate3d(100%, 0, 0)
  }
  .slide-fade-enter-active {
    transition: all .3s ease;
  }
  .slide-fade-leave-active {
    transition: all .3s ease;
  }
  .slide-fade-enter, .slide-fade-leave-to
    /* .slide-fade-leave-active for below version 2.1.8 */ {
    transform: translateY(10px);
    opacity: 0;
  }
  .help{
    position: absolute;
    right: 0;
    top: 1.43rem;
    color: red;
  }
</style>
