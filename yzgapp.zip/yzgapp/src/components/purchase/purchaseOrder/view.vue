<template>
  <div>
    <ysl-header :title = 'audit.orderTypeName'></ysl-header>
    <audit-header :avator="avator" :orderTypeName="audit.orderTypeName" :selectType="selectType"></audit-header>
    <div class="audit-view" v-if="detailInfo">
      <audit-proccess :getProcess="getProccess"></audit-proccess>
      <div class="module-item">
        <div class="module-header" :class="{'isSpread' : false}">
          <span>基础信息</span>
        </div>
        <div class="module-main">
          <p class="p-base"><label>单据号</label>{{detailInfo.purchaseOrderNo}}</p>
          <p class="p-base"><label>采购单位</label>{{detailInfo.orgName}}</p>
          <p class="p-base"><label>制单人</label>{{detailInfo.staffName}}</p>
          <p class="p-base"><label>制单日期</label>{{detailInfo.addTime | formatDate}}</p>
          <p class="p-base"><label>合同号</label>{{detailInfo.contractNo|| '-'}}</p>
          <p class="p-base"><label>收货方式</label>{{detailInfo.receiveTypeName}}</p>
          <p class="p-base" v-if="detailInfo.receiveTypeId"><label>中转仓</label>{{detailInfo.detailVOs[0].splitRepositoryName}}</p>
        </div>
      </div>
      <div class="module-item">
        <div class="module-header">
          <span>供应商信息</span>
        </div>
        <div class="module-main">
          <p class="p-base"><label>供应商</label>{{detailInfo.vendorName}}</p>
          <p class="p-base"><label>发票类型</label>{{detailInfo.invoiceTypeName}}</p>
        </div>
      </div>
      <div class="module-item">
        <div class="module-header">
          <span>商品信息</span>
        </div>
        <div class="order-title p-base p-title" @click="show('product')" :class="{'isSpread' : product}">
          <label>采购合计</label><span class="text-yellow">{{total}}</span>
          <i class="icon iconfont icon-xialajiantou"></i>
        </div>
        <div class="module-main" v-show="product">
            <div class="product-info" v-for="item in productList">
              <p class="p-base p-title">{{item.productName}}</p>
              <p class="p-base"><label>采购单价</label><span class="text-yellow">{{item.purchaseApplyPrice}}</span></p>
              <p class="p-base"><label>采购数量</label><span class="text-yellow">{{item.purchaseApplyNum}}</span></p>
              <p class="p-base"><label>合作方式</label>{{item.cooperationTypeName}}</p>
              <p class="p-base"><label>结算方式</label>{{item.settleTypeName}}</p>
              <div class="p-base p-textarea">
                <label>明细备注</label>
                <div class="textarea-detail"><p>{{item.remark || '-'}}</p></div>
              </div>
              <div class="moudle-table">
                <div class="table-cell table-left flex-1">
                  <h3>收货单位</h3>
                </div>
                <div class="table-cell table-right flex-1">
                  <h3>数量</h3>
                </div>
              </div>
              <div class="p-base apply-item" v-for="store in item.purchase">
                {{store.receiveOrgName}}
                <div class="apply-number">
                  <span>{{store.purchaseOrderNum}}</span>
                </div>
              </div>
              <!--<div class="moudle-table">
                <div class="table-cell table-left w34">
                  <p>10</p>
                </div>
                <div class="table-cell table-middle">
                  <p>10</p>
                </div>
                <div class="table-cell table-right">
                  <p><a class="look-btn" href="#">查看 ></a></p>
                </div>
              </div>-->
          </div>
        </div>
      </div><!--moudle-item-->
      <div class="module-item">
        <div class="module-header" @click="show('assist')" :class="{'isSpread' : assist}">
          <span>辅助参考</span>
          <i class="icon iconfont icon-xialajiantou"></i>
        </div>
        <div class="module-main" v-show="assist">
          <div v-if="assistArray.length > 0">
            <div class="product-info" v-for="item in assistArray[0].content">
              <p class="p-base p-title">{{item.productName}}</p>
              <div class="p-base apply-item">
                <label>采购单价</label>
                <div class="apply-number">
                  <span>{{item.purchaseApplyNum}}</span>
                </div>
              </div>
              <div class="p-base apply-item">
                <label>近两周公司同型号销售</label>
                <div class="apply-number">
                  <span>{{item.nearTowWeekSaleNum}}</span>
                </div>
              </div>
              <div class="p-base apply-item">
                <label>公司同型号库存</label>
                <div class="apply-number">
                  <span>{{item.stockNum}}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div><!--moudle-item-->
      <div class="module-item">
        <div class="module-header">
          <span>单据备注</span>
        </div>
        <div class="module-main">
          <p class="p-base">{{detailInfo.remark || '暂无备注'}}</p>
        </div>
      </div>
      <div class="module-item" v-if="selectType === 1">
        <div class="module-header header-yellow">
          <span>审核备注</span>
        </div>
        <div class="module-main">
          <div class="audit-remark">
            <i class="icon iconfont icon-wenbenbianji"></i>
            <input type="text" v-model="remark" placeholder="（非必填）写备注..."/>
          </div>
        </div>
      </div>
    </div><!--audit-view-->
    <div class="audit-foot" v-if="selectType === 1">
      <button @click="submit(2)" type="submit" class="green">同意</button>
      <button @click="submit(4)" type="submit" class="reject">驳回</button>
      <button class="remark">备注</button>
    </div>
  </div>
</template>

<script>
  import yslHeader from '@/components/base/header/header'
  import {mapGetters} from 'vuex'
  import {getPurchaseDetail,queryCompanySales,queryCompanyStock,queryCompanyWhoesale,purchaseApprove,getApproveProcess} from 'assets/js/api/purchase'
  import auditProccess from '@/components/base/audit/audit-proccess'
  import auditHeader from '@/components/base/audit/audit-header'
  import {queryRefer,saveRefer} from 'assets/js/api/recommend'
  import { Toast } from 'mint-ui'
  import avator from '../../../assets/avator.png'
  export default {
    components: {
      yslHeader,
      auditProccess,
      auditHeader
    },
    data () {
      return {
        val : '',
        text : '',
        remark : '',
        entryType : '',
        avator : avator,
        sequence : false,
        assist : false,
        product : false,
        additional : false,
        assistArray : [],
        productList : [],
        stocks : {},
        products : {},
        pfList : {},
        detailInfo: {},
        isSaveRefer : 0,
        selectType: 1,
        total:0
      }
    },
    methods: {
      show (type) {
        switch (type){
          case 'sequence':
            this.sequence = !this.sequence;
            break;
          case 'assist':
            this.assist = !this.assist;
            break;
          case 'product':
            this.product = !this.product;
            break;
          case 'additional':
            this.additional = !this.additional;
            break;
        }
      },
      _queryCompanySales (param,products) {
        let _this = this,storeParam = {...param};
        storeParam.prodIds = products
        storeParam.orgId = _this.userHistory.orgId
        queryCompanySales(storeParam,function (res) {
          if(res.data.retStatus===0&&res.data.retData){
            _this.products = res.data.retData;
          }
        },function (err) {
          Toast(err.data.retDesc);
        });
      },
      _queryCompanyPf (param,products) {
        let _this = this,pfParam = {...param};
        pfParam.productIds = products
        pfParam.weeks = 2
        queryCompanyWhoesale(pfParam,function (res) {
          if(res.data.retStatus===0&&res.data.retData){
            _this.pfList = res.data.retData;
          }
        },function (err) {
          Toast(err.data.retDesc);
        });
      },
      _queryCompanyStock (param,products) {
        let _this = this,stockParam = {...param};
        stockParam.productIds = products
        stockParam.orgId = _this.userHistory.orgId
        stockParam.weeks = 2
        queryCompanyStock(stockParam,function (res) {
          if(res.data.retStatus===0&&res.data.retData){
            _this.stocks = res.data.retData;
          }
        },function (err) {
          Toast(err.message);
        });
      },
      _queryRefer (type) {
        let param = {
          orderId: this.audit.orderId,
          referType: type
        },result = [],_this = this;
        queryRefer(param,function (res) {
          result = res.data.rows;
          if(type === 1&&result) {
            _this.assistArray = result;
            if(result.length === 0){
              _this.isSaveRefer = 1;
              let param = {
                companyId: _this.userHistory.companyId
              },products = [];
              for(let i = 0 ; i < _this.detailInfo.detailVOs.length ; i++){
                products.push(_this.detailInfo.detailVOs[i].productId);
              }
              _this._queryCompanySales(param,products);
              _this._queryCompanyStock(param,products);
              _this._queryCompanyPf(param,products)

            }else {
              _this.assistArray[0].content = JSON.parse(_this.assistArray[0].content);
            }
          }
        },function (err) {

        });
      },
      getProccess (success) {
        let param = {
          orderId: this.audit.orderId
        };
        getApproveProcess(param,function (res) {
          if(res.data.retStatus != 1){
            success(res.data);
          }
        },function (err) {

        });
      },
      _getPurchaseDetail () {
        let params = {
          companyId: this.userHistory.companyId,
          purchaseApplyNo: this.audit.orderNo,
          "offset":0,
          "limit":1
        },_this = this;
        getPurchaseDetail(params,function (res) {
          if(res.data.retStatus === 1){
            Toast(res.data.retDesc);
            return;
          }
          _this.detailInfo = res.data.rows[0];
          for(let i = 0 ; i < _this.detailInfo.detailVOs.length ; i++){
            _this.total = _this.total + _this.detailInfo.detailVOs[i].purchaseOrderNum*_this.detailInfo.detailVOs[i].purchaseOrderPrice
          }
          _this._queryRefer(1);
          _this.filterDetail;
        },function (err) {
          Toast(err.message);
        });
      },
      updateRefer () {
        let detailVOs = this.detailInfo.detailVOs,_this = this;
        if(_this.assistArray.length === 0){
          _this.assistArray.push({
            content:[]
          })
        }
        _this.assistArray[0].content = [];
        for(let index in detailVOs){
          let pfNum = _this.pfList[detailVOs[index].productId] || 0,
            productsNum = _this.products[detailVOs[index].productId] || 0;
          _this.assistArray[0].content.push({
            productId: detailVOs[index].productId,
            productName: detailVOs[index].productName,
            nearTowWeekSaleNum: pfNum+productsNum,
            stockNum: _this.stocks[detailVOs[index].productId],
            purchaseApplyNum: detailVOs[index].purchaseOrderNum
          });
        }
      },
      _saveRefer () {
        let param = {
          content: '',
          referType: 1,
          orderId: this.audit.orderId
        }
        param.content = JSON.stringify(this.assistArray[0].content);
        saveRefer(param,function (res) {

        },function (err) {

        });
      },
      submit(type){
        let _this = this,
            params = {
            orderId : _this.audit.orderId,
            staffId : _this.userHistory.staffId,
            companyId : _this.userHistory.companyId,
            status : type,
            comment : _this.remark,
           };
        purchaseApprove(params,function (res) {
          if(res.data.retStatus === 0){
            if(type === 2){
              Toast({
                message: '审核成功',
                duration: 1000
              });
              if(_this.isSaveRefer){
                _this._saveRefer();
              }
            }else {
              Toast({
                message: '驳回成功',
                duration: 1000
              });
            }
            _this.$router.push({
              path: '/purchase/store/list',
              query:{entryType:_this.entryType}
            })
          }
          if(res.data.retStatus === 1){
            Toast({
              message: res.data.retDesc,
              duration: 1000
            });
          }
        },function (err) {

        });
      }
    },
    mounted() {
      this._getPurchaseDetail();
      this.selectType = this.audit.selectId
    },
    computed: {
      filterDetail (){
        let _this = this ,detailVOs = _this.detailInfo.detailVOs;
        for(let j = 0 ; j < detailVOs.length ; j++){
          let flag = 0;
          let purchase = detailVOs[j];
          purchase.orgName = _this.detailInfo.orgName;
          purchase.orgId = _this.detailInfo.orgId;
          purchase.purchaseApplyPrice = purchase.purchaseOrderPrice;
          purchase.purchaseApplyApprovedNum = purchase.purchaseOrderNum;
          for(let m = 0 ; m < _this.productList.length ; m++){
            if(_this.productList[m].productId == detailVOs[j].productId){
              let purchaseFlag = 0;
              let purchaseApplyNum = 0;
              _this.productList[m].purchase.forEach((item,index)=>{
                if(item.purchaseOrderNo == detailVOs[j].purchaseOrderNo){
                  purchaseFlag = 1;
                }
              })
              if(purchaseFlag == 0){
                purchaseApplyNum = parseInt(_this.productList[m].purchaseApplyNum)+parseInt(purchase.purchaseOrderNum);
                _this.productList[m].purchaseApplyNum = purchaseApplyNum;
                _this.productList[m].purchase.push(purchase);
              }
              flag = 1;
            }
          }
          if(flag === 0){
            _this.productList.push({
              productId :  detailVOs[j].productId,
              productName : detailVOs[j].productName,
              purchaseApplyNum : detailVOs[j].purchaseOrderNum,
              purchaseApplyPrice : detailVOs[j].purchaseOrderPrice,
              cooperationTypeName : detailVOs[j].cooperationTypeName,
              settleTypeName : detailVOs[j].settleTypeName,
              remark : detailVOs[j].remark,
              purchase : [
                purchase
              ]
            })
          }
        }
      },
      ...mapGetters([
        'audit',
        'userHistory'
      ])
    },
    created() {
      this.entryType = this.$route.query.entryType
    },
    watch: {
      stocks () {
        this.updateRefer();
      },
      products () {
        this.updateRefer();
      },
      pfList () {
        this.updateRefer();
      }
    }
  }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .slide-enter-active, .slide-leave-active{
    transition: all 0.3s
  }
  .slide-enter, .slide-leave-to{
    transform: translate3d(100%, 0, 0)
  }
  .slide-fade-enter-active {
    transition: all .3s ease;
  }
  .slide-fade-leave-active {
    transition: all .3s ease;
  }
  .slide-fade-enter, .slide-fade-leave-to
    /* .slide-fade-leave-active for below version 2.1.8 */ {
    transform: translateY(10px);
    opacity: 0;
  }
  .help{
    position: absolute;
    right: 0;
    top: 1.43rem;
    color: red;
  }
</style>
