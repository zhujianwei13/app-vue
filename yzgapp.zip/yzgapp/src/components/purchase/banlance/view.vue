<template>
  <div>
    <ysl-header :title = 'audit.orderTypeName'></ysl-header>
    <audit-header :avator="avator" :orderTypeName="audit.orderTypeName" :selectType="selectType"></audit-header>
    <div class="audit-view" v-if="detailInfo">
      <audit-proccess :getProcess="getProccess"></audit-proccess>
      <div class="module-item">
        <div class="module-header">
          <span>基础信息</span>
        </div>
        <div class="module-main">
          <p class="p-base"><label>单据号</label>{{detailInfo.paymentApplyId}}</p>
          <p class="p-base"><label>采购单位</label>{{detailInfo.orgName}}</p>
          <p class="p-base"><label>制单人</label>{{detailInfo.staffName}}</p>
          <p class="p-base"><label>制单日期</label>{{detailInfo.addTime | formatDate}}</p>
        </div>
      </div>
      <div class="module-item">
        <div class="module-header">
          <span>供应商信息</span>
        </div>
        <div class="module-main">
          <p class="p-base"><label>供应商</label>{{detailInfo.vendorName}}</p>
          <p class="p-base"><label>账户</label>{{detailInfo.depositAccount}} {{detailInfo.accountNum}}</p>
          <p class="p-base"><label>结算类型</label>{{settlemenType[detailInfo.settlemenType]}}</p>
          <p class="p-base"><label>结算方式</label>{{settlemenMode[detailInfo.settlemenMode]}}</p>
          <p class="p-base"><label>结算金额</label><span class="text-yellow">{{detailInfo.totalAmount}}</span></p>
        </div>
      </div>
      <div v-if="detailInfo.settlemenType === 2">
        <!--返利-->
        <div class="module-item" v-if="detailInfo.settlemenMode === 1">
          <div class="module-header">
            <span>返利款使用信息</span>
          </div>
          <div class="order-title p-base p-title" @click="show('banlanceType')" :class="{'isSpread' : banlanceType}">
            <label>使用合计</label><span class="text-yellow">50000.00</span>
            <i class="icon iconfont icon-xialajiantou"></i>
          </div>
          <div class="module-main" v-show="banlanceType">
            <section v-for="item in detailInfo.paymentApplyPreparationRecordList">
              <p class="p-base"><label>单据号</label>{{item.orderNo}}</p>
              <p class="p-base"><label>供应商</label></p>
              <p class="p-base"><label>返利金额</label>{{item.totalAmount}}</p>
              <p class="p-base"><label>可使用返利</label>{{item.willAmount}}</p>
              <p class="p-base"><label>本次使用</label><span class="text-yellow">{{item.useAmount}}</span></p>
            </section>
          </div>
        </div><!--moudle-item-->
        <!--价保-->
        <div class="module-item" v-if="detailInfo.settlemenMode === 2">
          <div class="module-header">
            <span>价保款使用信息</span>
          </div>
          <div class="order-title p-base p-title" @click="show('banlanceType')" :class="{'isSpread' : banlanceType}">
            <label>使用合计</label><span class="text-yellow">50000.00</span>
            <i class="icon iconfont icon-xialajiantou"></i>
          </div>
          <div class="module-main" v-show="banlanceType">
            <section v-for="item in detailInfo.paymentApplyPreparationRecordList">
              <p class="p-base"><label>单据号</label>{{item.orderNo}}</p>
              <p class="p-base"><label>供应商</label></p>
              <p class="p-base"><label>价保金额</label>{{item.totalAmount}}</p>
              <p class="p-base"><label>可使用价保</label>{{item.willAmount}}</p>
              <p class="p-base"><label>本次使用</label><span class="text-yellow">{{item.useAmount}}</span></p>
            </section>
          </div>
        </div><!--moudle-item-->
        <!--预付款-->
        <div class="module-item" v-if="detailInfo.settlemenMode === 3">
          <div class="module-header">
            <span>预付款使用信息</span>
          </div>
          <div class="order-title p-base p-title" @click="show('banlanceType')" :class="{'isSpread' : banlanceType}">
            <label>使用合计</label><span class="text-yellow">50000.00</span>
            <i class="icon iconfont icon-xialajiantou"></i>
          </div>
          <div class="module-main" v-show="banlanceType">
            <section v-for="item in detailInfo.paymentApplyPreparationRecordList">
              <p class="p-base"><label>单据号</label>{{item.orderNo}}</p>
              <p class="p-base"><label>供应商</label></p>
              <p class="p-base"><label>实付金额</label>{{item.totalAmount}}</p>
              <p class="p-base"><label>可用金额</label>{{item.willAmount}}</p>
              <p class="p-base"><label>本次使用</label><span class="text-yellow">{{item.useAmount}}</span></p>
            </section>
          </div>
        </div><!--moudle-item-->
      </div>
      <!--默认-->
      <div class="module-item">
        <div class="module-header">
          <span>关联采购单据信息</span>
        </div>
        <div class="order-title p-base p-title" @click="show('product')" :class="{'isSpread' : product}">
          <label>申请合计</label><span class="text-yellow">{{detailInfo.totalAmount}}</span>
          <i class="icon iconfont icon-xialajiantou"></i>
        </div>
        <div class="module-main" v-show="product">
          <div class="product-info" v-for="item in detailInfo.paymentApplyPurchaseMappingList">
            <p class="p-base"><label>采购单号</label>{{item.purchaseOrderNo}}</p>
            <p class="p-base"><label>已结算金额</label>{{item.realSettleAmount}}</p>
            <p class="p-base"><label>待结算金额</label>{{item.awaitAmount}}</p>
            <p class="p-base"><label>申请结算</label><span class="text-yellow">{{item.settleAmount}}</span></p>
            <p class="p-base mt10"><label>已核销发票</label>{{item.invoiceMoneyPoolDO.happendInvoice}}</p>
            <p class="p-base"><label>待核销发票</label>{{item.invoiceMoneyPoolDO.willInvoice}}</p>
            <div v-for="orderDetail in item.purchaseOrderDetailList">
              <p class="p-base p-title mt20">{{orderDetail.productName}}</p>
              <p class="p-base"><label>采购单价</label>{{orderDetail.purchaseOrderPrice}}</p>
              <p class="p-base"><label>采购数量</label>{{orderDetail.purchaseOrderNum}}</p>
              <p class="p-base"><label>采购总价</label>{{orderDetail.purchaseOrderNum*orderDetail.purchaseOrderPrice}}</p>
              <p class="p-base"><label>待入数量</label></p>
              <p class="p-base"><label>实入数量</label></p>
            </div>
          </div>
        </div>
      </div><!--moudle-item-->
      <div class="module-item">
        <div class="module-header">
          <span>单据备注</span>
        </div>
        <div class="module-main">
          <p class="p-base">{{detailInfo.remark || '暂无备注'}}</p>
        </div>
      </div>
      <div class="module-item" v-if="selectType === 1">
        <div class="module-header header-yellow">
          <span>审核备注</span>
        </div>
        <div class="module-main">
          <div class="audit-remark">
            <i class="icon iconfont icon-wenbenbianji"></i>
            <input type="text" v-model="remark" placeholder="（非必填）写备注..."/>
          </div>
        </div>
      </div>
    </div><!--audit-view-->
    <div class="audit-foot" v-if="selectType === 1">
      <button @click="submit(2)" type="submit" class="green">同意</button>
      <button @click="submit(4)" type="submit" class="reject">驳回</button>
      <button class="remark">备注</button>
    </div>
  </div>
</template>

<script>
  import yslHeader from '@/components/base/header/header'
  import {mapGetters} from 'vuex'
  import {paymentApply,paymentApprove,paymentApproveBack,getApproveProcess} from 'assets/js/api/purchase'
  import auditProccess from '@/components/base/audit/audit-proccess'
  import auditHeader from '@/components/base/audit/audit-header'
  import { Toast } from 'mint-ui'
  import {dateFormat} from 'assets/js/util'
  import avator from '../../../assets/avator.png'
  import {settlemenType,settlemenMode} from 'assets/js/config'
  export default {
    components: {
      yslHeader,
      auditProccess,
      auditHeader
    },
    data () {
      return {
        remark : '',
        entryType : '',
        avator : avator,
        product : false,
        selectType: 1,
        banlanceType : false,
        settlemenType : settlemenType,
        settlemenMode : settlemenMode,
        additional : false,
        detailInfo : {}
      }
    },
    methods: {
      show (type) {
        switch (type){
          case 'product':
            this.product = !this.product;
            break;
          case 'banlanceType':
            this.banlanceType = !this.banlanceType;
            break;
        }
      },
      getProccess (success) {
        let param = {
          orderId: this.audit.orderId
        };
        getApproveProcess(param,function (res) {
          if(res.data.retStatus != 1){
            success(res.data);
          }
        },function (err) {

        });
      },
      _getPurchaseDetail () {
        let params = {
          paymentApplyId: this.audit.orderNo
        },_this = this;
        paymentApply(params,function (res) {
          if(res.data.retStatus === 1){
            Toast(res.data.retDesc);
            return;
          }
          _this.detailInfo = res.data.retData;
        },function (err) {
          Toast(err.message);
        });
      },
      submit (type) {
        let _this = this,
          params = {
            paymentAppyId : _this.audit.orderNo,
            approveStaffId : _this.userHistory.staffId,
            companyId : _this.userHistory.companyId,
            comment : _this.remark,
          };
        if(type === 2){
          paymentApprove(params,function (res) {
            if(res.data.retStatus === 0){
              Toast({
                message: '审核成功',
                duration: 1000
              });
              _this.$router.push({
                path: '/purchase/store/list',
                query:{entryType:_this.entryType}
              })
            }
            if(res.data.retStatus === 1){
              Toast({
                message: res.data.retDesc,
                duration: 1000
              });
            }
          },function (err) {

          });
        }
        if(type === 4){
          paymentApproveBack(params,function (res) {
            if(res.data.retStatus === 0){
              Toast({
                message: '驳回成功',
                duration: 1000
              });
              _this.$router.push({
                path: '/purchase/store/list'
              })
            }
            if(res.data.retStatus === 1){
              Toast({
                message: res.data.retDesc,
                duration: 1000
              });
            }
          },function (err) {

          });
        }

      }
    },
    mounted() {
      this._getPurchaseDetail();
      this.selectType = this.audit.selectId
    },
    created() {
      this.entryType = this.$route.query.entryType
    },
    computed: {
      ...mapGetters([
        'audit',
        'userHistory'
      ])
    }
  }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .slide-enter-active, .slide-leave-active{
    transition: all 0.3s
  }
  .slide-enter, .slide-leave-to{
    transform: translate3d(100%, 0, 0)
  }
  .slide-fade-enter-active {
    transition: all .3s ease;
  }
  .slide-fade-leave-active {
    transition: all .3s ease;
  }
  .slide-fade-enter, .slide-fade-leave-to
    /* .slide-fade-leave-active for below version 2.1.8 */ {
    transform: translateY(10px);
    opacity: 0;
  }
  .help{
    position: absolute;
    right: 0;
    top: 1.43rem;
    color: red;
  }
</style>
