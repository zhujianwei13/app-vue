<template>
    <div>
      <ysl-header :title = 'audit.orderTypeName'></ysl-header>
      <audit-header :avator="avator" :orderTypeName="audit.orderTypeName" :selectType="selectType"></audit-header>
      <form @submit.prevent="validateBeforeSubmit">
      <div class="audit-view">
        <audit-proccess :getProcess="getProccess"></audit-proccess>
        <div class="module-item">
          <div class="module-header">
            <span>基础信息</span>
          </div>
          <div class="module-main" v-if="detailInfo">
            <p class="p-base"><label>单据号</label>{{detailInfo.purchaseApplyNo}}</p>
            <p class="p-base"><label>制单单位</label>{{detailInfo.orgName}}</p>
            <p class="p-base"><label>制单人</label>{{detailInfo.staffName}}</p>
            <p class="p-base"><label>制单日期</label>{{detailInfo.addTime | formatDate }}</p>
          </div>
        </div>
        <div class="module-item">
          <div class="module-header">
            <span>商品信息</span>
          </div>
          <div class="module-main">
            <div v-if="detailInfo">
            <div class="product-info" v-for="item in detailInfo.detailVOs">
              <p class="p-base p-title">{{item.productName}}</p>
              <p class="p-base"><label>预估单价</label>{{item.purchaseApplyPrice}}</p>
              <p class="p-base"><label>申请数量</label>{{item.purchaseApplyNum}}</p>
              <p class="p-base"><label>预估总价</label>{{item.purchaseApplyPrice*item.purchaseApplyNum}}</p>
              <p class="p-base"><label>供应商</label>{{item.vendorName}}</p>
              <p class="p-base"><label>发票类型</label>{{item.invoiceTypeName}}</p>
              <div class="p-base p-textarea">
                <label>明细备注</label>
                <div class="textarea-detail"><p>{{item.remark || '-'}}</p></div>
              </div>
            </div>
            </div>
          </div>
        </div><!--moudle-item-->
        <div class="module-item">
          <div class="module-header" @click="show('assist')" :class="{'isSpread' : assist}">
            <span>辅助参考</span>
            <i class="icon iconfont icon-xialajiantou"></i>
          </div>
          <div class="module-main" v-show="assist">
            <div v-if="assistArray.length > 0">
            <div class="product-info" v-for=" item in assistArray[0].content">
              <p class="p-base">{{item.productName}}</p>
              <div class="moudle-table">
                <div class="table-cell table-left w34">
                  <h3>采购数量</h3>
                  <p>{{item.purchaseApplyNum}}</p>
                </div>
                <div class="table-cell table-middle">
                  <h3>近两周门店同型号销售</h3>
                  <p>{{item.nearTowWeekSaleNum}}</p>
                </div>
                <div class="table-cell table-right">
                  <h3>门店同型号库存</h3>
                  <p>{{item.stockNum}}</p>
                </div>
              </div>
            </div>
            </div>
          </div>
        </div><!--moudle-item-->
        <div class="module-item">
          <div class="module-header">
            <span>单据备注</span>
          </div>
          <div class="module-main">
            <p class="p-base" v-if="detailInfo">{{detailInfo.remark || '暂无备注'}}</p>
          </div>
        </div>
        <div class="module-item">
          <div class="module-header header-yellow" @click="show('additional')" :class="{'isSpread' : additional}">
            <span>补充参考</span>
            <i class="icon iconfont icon-xialajiantou"></i>
          </div>
          <div class="module-main" v-show="additional">
            <div v-if="referList.length > 0">
            <div class="product-info" v-for="item in referList[0].content">
              <p class="p-base">{{item.productName}}</p>
              <div class="moudle-table">
                <div class="table-cell table-left w34">
                  <h3>采购数量</h3>
                  <p>{{item.purchaseApplyNum}}</p>
                </div>
                <div class="table-cell table-middle">
                  <h3>近两周公司同型号销售</h3>
                  <p>{{item.nearTowWeekSaleNum}}</p>
                </div>
                <div class="table-cell table-right">
                  <h3>公司同型号库存</h3>
                  <p>{{item.stockNum}}</p>
                </div>
              </div>
            </div>
            </div>
          </div>
        </div>
        <div class="module-item">
          <div class="module-header header-yellow">
            <span>审核信息</span>
          </div>
          <div class="module-main" v-if="detailInfo">
            <div class="product-info" v-for="(item,index) in detailInfo.detailVOs">
              <p class="p-base">{{item.productName}}</p>
              <div class="p-base apply-item">
                <label>申请数量</label>
                <div class="apply-number">
                  <span>{{item.purchaseApplyNum}}</span>
                </div>
              </div>
              <div class="p-base apply-item">
                <label><span class="mustStyle">* </span>核准数量</label>
                <div class="apply-number">
                  <input v-if="selectType === 1" v-model="item.hzNum" type="text" :class="{'input': true, 'is-danger': errors.has('zhNum') }" data-vv-as='核准数量' name="zhNum" alias="核准数量"  v-validate="'required|numeric'"/>
                  <span v-if="selectType === 2">{{item.purchaseApplyApprovedNum}}</span>
                </div>
                <span v-show="errors.has('zhNum')" class="help is-danger">{{ errors.first('zhNum') }}</span>
              </div>
            </div>
          </div>
        </div>
        <div class="module-item" v-if="selectType === 1">
          <div class="module-header header-yellow">
            <span>审核备注</span>
          </div>
          <div class="module-main">
            <div class="audit-remark">
              <i class="icon iconfont icon-wenbenbianji"></i>
              <input type="text" v-model="remark" placeholder="（非必填）写备注..."/>
            </div>
          </div>
        </div>
      </div><!--audit-view-->
      <div class="audit-foot" v-if="selectType === 1">
        <button @click="submit(2)" type="submit" class="green">同意</button>
        <button @click="submit(4)" type="submit" class="reject">驳回</button>
        <button class="remark">备注</button>
      </div>
      </form>
    </div>
</template>

<script>
  import yslHeader from '@/components/base/header/header'
  import auditProccess from '@/components/base/audit/audit-proccess'
  import auditHeader from '@/components/base/audit/audit-header'
  import {mapGetters} from 'vuex'
  import {queryRefer,saveRefer} from 'assets/js/api/recommend'
  import {getStoreDetail,queryCompanySales,queryCompanyStock,queryCompanyWhoesale,storeApprove,getApproveProcess} from 'assets/js/api/purchase'
  import avator from '../../../assets/avator.png'
  import { Toast } from 'mint-ui'
  import qs from 'qs'
  export default {
    components: {
      yslHeader,
      auditProccess,
      auditHeader
    },
    data () {
      return {
        val : '',
        remark : '',
        entryType : '',
        avator : avator,
        sequence : false,
        assist : false,
        additional : false,
        assistArray: [],
        referList: [],
        stocks : {},
        products : {},
        pfList : {},
        auxiliary : [],
        detailInfo: {},
        approveProccess: [],
        isSaveRefer: 0,
        selectType:1,
        referOther: [],
        status: 0,
      }
    },
    methods: {
      show (type) {
        switch (type){
          case 'sequence':
            this.sequence = !this.sequence;
            break;
          case 'assist':
            this.assist = !this.assist;
            break;
          case 'additional':
            this.additional = !this.additional;
            break;
        }
      },
      _queryCompanySales (param,products) {
        let _this = this,storeParam = {...param};
        storeParam.prodIds = products
        storeParam.orgId = _this.userHistory.orgId
        queryCompanySales(storeParam,function (res) {
          if(res.data.retStatus===0&&res.data.retData){
            _this.products = res.data.retData;
          }
        },function (err) {
          Toast(err.data.retDesc);
        });
      },
      _queryCompanyPf (param,products) {
        let _this = this,pfParam = {...param};
        pfParam.productIds = products
        pfParam.weeks = 2
        queryCompanyWhoesale(pfParam,function (res) {
          if(res.data.retStatus==0&&res.data.retData){
            _this.pfList = res.data.retData;
          }
        },function (err) {
          Toast(err.data.retDesc);
        });
      },
      _queryCompanyStock (param,products) {
        let _this = this,stockParam = {...param};
        stockParam.productIds = products
        stockParam.orgId = _this.userHistory.orgId
        stockParam.weeks = 2
        queryCompanyStock(stockParam,function (res) {
          if(res.data.retStatus==0&&res.data.retData){
            _this.stocks = res.data.retData;
          }
        },function (err) {
          Toast(err.message);
        });
      },
      validateBeforeSubmit () {
        let _this = this,
          detailVOs = _this.detailInfo.detailVOs;
        this.$validator.validateAll().then((result) => {
          if (result) {
            let params = {
              orderId : _this.audit.orderId,
              staffId : _this.userHistory.staffId,
              companyId : _this.userHistory.companyId,
              status : _this.status,
              comment : _this.remark,
              items : ''
            },approvelist = [];
            for(let i = 0 ; i < detailVOs.length ; i++){
              approvelist.push({
                detailId: detailVOs[i].id,
                purchaseApplyApprovedNum: detailVOs[i].hzNum
              });
            }
            params.items = JSON.stringify(approvelist);
            storeApprove(params,function (res) {
              if(res.data.retStatus === 0){
                if(_this.status === 2){
                  Toast({
                    message: '审核成功',
                    duration: 1000
                  });
                }
                if(_this.status === 4){
                  Toast({
                    message: '驳回成功',
                    duration: 1000
                  });
                }
                if(_this.isSaveRefer){
                  _this._saveRefer();
                }
                _this.$router.push({
                  path: '/purchase/store/list',
                  query:{entryType:_this.entryType}
                })
              }
            },function (err) {

            });
          }
        });
      },
      submit (type) {
        this.status = type;
      },
      getProccess (success) {
        let param = {
          orderId: this.audit.orderId
        };
        getApproveProcess(param,function (res) {
          if(res.data.retStatus != 1){
            success(res.data);
          }
        },function (err) {

        });
      },
      _getStoreDetail () {
        let params = {
          approveStaffId:this.userHistory.staffId,
          companyId: this.userHistory.companyId,
          purchaseApplyNo: this.audit.orderNo,
          "offset":0,
          "limit":1
        },_this = this;
        getStoreDetail(params,function (res) {
          if(res.data.retStatus === 1){
            Toast(res.data.retDesc);
            return;
          }
          _this.detailInfo = res.data.rows[0];
          _this._queryRefer(2);
        },function (err) {
          Toast(err.message);
        });
      },
      _queryRefer (type) {
        let param = {
          orderId: this.audit.orderId,
          referType: type
        },result = [],_this = this;
        queryRefer(param,function (res) {
          result = res.data.rows
          if(type === 1&&result){
            _this.assistArray = result;
            if(_this.assistArray.length > 0 ){
              _this.assistArray[0].content = JSON.parse(_this.assistArray[0].content);
            }
          }
          if(type === 2&&result){
            _this.referList = result
            if(result.length == 0){
              _this.isSaveRefer = 1;
              let param = {
                companyId: _this.userHistory.companyId
              },products = [];
              for(let i = 0 ; i < _this.detailInfo.detailVOs.length ; i++){
                products.push(_this.detailInfo.detailVOs[i].productId);
                _this.detailInfo.detailVOs[i].hzNum = ''
              }
              _this._queryCompanySales(param,products)
              _this._queryCompanyStock(param,products)
              _this._queryCompanyPf(param,products)

            }else {
              _this.referList[0].content = JSON.parse(_this.referList[0].content);
            }
          }
        },function (err) {

        });
      },
      updateRefer () {
        let detailVOs = this.detailInfo.detailVOs,_this = this;
        if(_this.referList.length === 0){
          _this.referList.push({
            content:[]
          })
        }
        _this.referList[0].content = [];
        console.log('content: ',_this.referList[0].content);
        for(let index in detailVOs){
          let pfNum = _this.pfList[detailVOs[index].productId] || 0,
              productsNum = _this.products[detailVOs[index].productId] || 0;
          _this.referList[0].content.push({
            productId: detailVOs[index].productId,
            productName: detailVOs[index].productName,
            nearTowWeekSaleNum: pfNum+productsNum,
            stockNum: _this.stocks[detailVOs[index].productId],
            purchaseApplyNum: detailVOs[index].purchaseApplyNum
          });
        }
      },
      _saveRefer () {
        let param = {
          content: '',
          referType: 2,
          orderId: this.audit.orderId
        }
        param.content = JSON.stringify(this.referList[0].content);
        saveRefer(param,function (res) {

        },function (err) {

        });
      }
    },
    created() {
      this.entryType = this.$route.query.entryType
    },
    mounted() {
      this._getStoreDetail();
      this._queryRefer(1);
      this.selectType = this.audit.selectId
    },
    computed: {
      ...mapGetters([
        'audit',
        'userHistory'
      ])
    },
    watch: {
      stocks () {
        this.updateRefer();
      },
      products () {
        this.updateRefer();
      },
      pfList () {
        this.updateRefer();
      }
    }
  }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .slide-enter-active, .slide-leave-active{
    transition: all 0.3s
  }
 .slide-enter, .slide-leave-to{
   transform: translate3d(100%, 0, 0)
 }
  .slide-fade-enter-active {
    transition: all .3s ease;
  }
  .slide-fade-leave-active {
    transition: all .3s ease;
  }
  .slide-fade-enter, .slide-fade-leave-to
    /* .slide-fade-leave-active for below version 2.1.8 */ {
    transform: translateY(10px);
    opacity: 0;
  }
  .help{
    position: absolute;
    right: 0;
    top: 0.61rem;
    color: red;
  }
</style>
