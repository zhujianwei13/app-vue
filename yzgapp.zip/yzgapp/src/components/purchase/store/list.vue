<template>
  <div class="container padding-sh-list">
    <ysl-header :title = 'title'></ysl-header>
    <audit-tab :type = 'type' :entryType="entryType" :loadMore="loadMore" :loadwillMore="loadwillMore" @selected="changeApprove($event)" :pageSize="pageSize" :expireNumber="expireNumber"></audit-tab>
    <search-tab @changeType="changeType($event)" :resultNum="type" :typeList="typeList"></search-tab>
  </div>
</template>

<script>
    import yslHeader from '@/components/base/header/header'
    import auditTab from '@/components/base/audit/audit-tab'
    import searchTab from '@/components/base/audit/search'
    import {mapGetters} from 'vuex'
    import {entryOrderType} from 'assets/js/config'
    import {getApproved,getApprovedWill} from 'assets/js/api/purchase'
    import {getAuditType} from 'assets/js/api/recommend'
    import { Toast } from 'mint-ui';
    export default {
      components: {
        yslHeader,
        auditTab,
        searchTab
      },
      data () {
        return {
          title : '审核列表',
          type : 0,
          pageIndex: 0,
          pagewillIndex: 0,
          pageSize: 10,
          close : false,
          selected : 1,
          expireNumber: 0,
          entryType:'',
          typeList: []
        }
      },
      methods: {
        changeType (type) {
          this.type = type;
          console.log(type);
        },
        changeApprove (val) {
          this.selected = val;
        },
        loadMore (cb,error) {
          let _this = this,singleType = [];
          if(this.type===0){
            singleType = entryOrderType[this.entryType]
          }else {
            singleType.push(this.type)
          }
          let param = {
            companyId: this.userHistory.companyId,
            staffId: this.userHistory.staffId,
            limit: this.pageSize,
            orderTypeList: singleType,
            offset: this.pageIndex*this.pageSize
          }

          getApproved(param,function (res) {
            if(res.data.retStatus === 1){
              error(res.data);
              Toast(res.data.retDesc);
              return;
            }
            cb(res.data.rows);
            _this.pageIndex ++;

          },function (err) {

          });
        },
        loadwillMore (cb,error) {
          let _this = this,singleType = [];
          if(this.type===0){
            singleType = entryOrderType[this.entryType]
          }else {
            singleType.push(this.type)
          }
          let param = {
            companyId: this.userHistory.companyId,
            staffId: this.userHistory.staffId,
            limit: this.pageSize,
            orderTypeList: singleType,
            offset: this.pagewillIndex*this.pageSize
          }
          getApprovedWill(param,function (res) {
            if(res.data.retStatus === 1){
              error(res.data);
              Toast(res.data.retDesc);
              return;
            }
            _this.expireNumber = res.data.total;
            cb(res.data.rows);
            _this.pagewillIndex ++;

          },function (err) {

          });
        }
      },
      filters: {},
      method: {

      },
      computed: {
        ...mapGetters(['userHistory'])
      },
      created () {
        this.entryType = this.$route.query.entryType
      },
      watch: {
        type (){
          this.pageIndex = 0;
          this.pagewillIndex = 0;
        },
        selected () {
          this.pageIndex = 0;
          this.pagewillIndex = 0;
        }
      },
      mounted () {
        let _this = this,menuType = [];
        menuType = entryOrderType[this.entryType];
        let param = {
          staffId: this.userHistory.staffId,
          companyId: this.userHistory.companyId,
          "offset":0,
          "limit":100,
          orderTypeList : menuType
        };
        getAuditType(param,function (res) {
          let _data  = res.data.retData;
          _this.typeList = _data;
        },function (err) {

        });
      },
      destroyed () {}
    }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
</style>
