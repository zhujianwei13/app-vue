<template>
  <div>
    <ysl-header :title = 'audit.orderTypeName'></ysl-header>
    <audit-header :avator="avator" :orderTypeName="audit.orderTypeName" :selectType="selectType"></audit-header>
    <form @submit.prevent="validateBeforeSubmit">
      <div class="audit-view">
        <audit-proccess :getProcess="getProccess"></audit-proccess>
        <div class="module-item">
          <div class="module-header" :class="{'isSpread' : false}">
            <span>基础信息</span>
          </div>
          <div class="module-main">
            <p class="p-base"><label>单据号</label>{{detailInfo.advanceChargeNo}}</p>
            <p class="p-base"><label>制单单位</label>{{detailInfo.orgName}}</p>
            <p class="p-base"><label>制单人</label>{{detailInfo.staffName}}</p>
            <p class="p-base"><label>制单日期</label>{{detailInfo.addTime | formatDate }}</p>
          </div>
        </div>
        <div class="module-item">
          <div class="module-header" :class="{'isSpread' : false}">
            <span>客户信息</span>
          </div>
          <div class="module-main">
            <p class="p-base"><label>客户</label>{{detailInfo.customerName}}</p>
            <p class="p-base"><label>预收款金额</label>{{detailInfo.totalMoney}}</p>
          </div>
        </div>
        <div class="module-item">
          <div class="module-header" @click="show('assist')" :class="{'isSpread' : false}">
            <span>商品信息</span>
          </div>
          <div class="module-main">
            <h4 class="p-base" style="margin-bottom: 12px">销售合计:<span style="color: #e2b21c">{{detailInfo.payThreshold}}</span></h4>
            <div class="product-info" v-for="item in detailInfo.details">
              <p class="p-base p-title">{{item.productName}}</p>
              <p class="p-base"><label>批发单价</label><span style="color: #e2b21c">{{item.orderPrice}}</span></p>
              <p class="p-base"><label>批发数量</label>{{item.orderNum}}</p>
              <p class="p-base"><label>批发总价</label><span style="color: #e2b21c">{{item.orderPrice * item.orderNum}}</span></p>
              <div class="p-base p-textarea">
                <label>明细备注</label>
                <div class="textarea-detail">{{item.remark}}</div>
              </div>
            </div>
          </div>
        </div><!--moudle-item-->
        <div class="module-item">
          <div class="module-header" :class="{'isSpread' : false}">
            <span>单据备注</span>
          </div>
          <div class="module-main">
            <p class="p-base">{{detailInfo.remark || '暂无备注'}}</p>
          </div>
        </div>
        <div class="module-item">
          <div class="module-header header-yellow" :class="{'isSpread' : false}">
            <span>审核备注</span>
          </div>
          <div class="module-main">
            <div class="audit-remark">
              <input type="text" v-model="remark" placeholder="（非必填）写备注..."/>
            </div>
          </div>
        </div>
      </div><!--audit-view-->
      <div class="audit-foot">
        <button @click="submitY()" type="submit" class="green">同意</button>
        <button @click="submitN()" type="submit" class="reject">驳回</button>
        <button class="remark">备注</button>
      </div>
    </form>
  </div>
</template>

<script type="text/ecmascript-6">
  import yslHeader from '@/components/base/header/header'
  import auditProccess from '@/components/base/audit/audit-proccess'
  import auditHeader from '@/components/base/audit/audit-header'
  import {mapGetters} from 'vuex'
  import {getStoreDetailYsk,storeApproveYskY,storeApproveYskN,getApproveProcessYsk} from 'assets/js/api/wholesaleApi'
  import {dateFormat} from 'assets/js/util'
  import avator from '../../../assets/avator.png'
  import { Toast, MessageBox  } from 'mint-ui'
  export default {
    components: {
      yslHeader,
      auditProccess,
      auditHeader
    },
    filters: {
      formatDate(time) {
        var date = new Date(time);
        return dateFormat(date, 'yyyy-MM-dd hh:mm:ss');
      }
    },
    data () {
      return {
        val : '',
        text : '',
        remark : '',
        avator : avator,
        sequence : false,
        assist : false,
        additional : false,
        stocks : [],
        products : [],
        auxiliary : [],
        detailInfo: {},
        status: 0,
      }
    },
    methods: {
      show (type) {
        switch (type){
          case 'sequence':
            this.sequence = !this.sequence;
            break;
          case 'assist':
            this.assist = !this.assist;
            break;
          case 'additional':
            this.additional = !this.additional;
            break;
        }
      },
      submitY(){
        let _this = this;
        let param = {
          orderId : this.detailInfo.advanceChargeNo,
          comment : this.remark,
          companyId: this.userHistory.companyId,
          orgId:this.userHistory.orgId,
          staffId: this.userHistory.staffId,
        }
        MessageBox.confirm('确定执行此操作?').then(action => {
          storeApproveYskY(param,function (res) {
            if(res.data.retStatus === 1){
              Toast(res.data.retDesc);
              return;
            }else if(res.data.retStatus === 0){
              Toast({
                message: '操作成功:已同意',
                iconClass: 'icon icon-success'
              });
              _this.$router.push({
                path: '/purchase/store/list',
                query:{entryType:_this.entryType}
              })
            }
          },function (err) {

          });
        })
      },
      submitN(){
        let _this = this;
        let param = {
          orderId : this.detailInfo.advanceChargeNo,
          comment : this.remark,
          companyId: this.userHistory.companyId,
          orgId:this.userHistory.orgId,
          staffId: this.userHistory.staffId,
        }
        MessageBox.confirm('确定执行此操作?').then(action => {
          storeApproveYskN(param,function (res) {
            if(res.data.retStatus === 1){
              Toast(res.data.retDesc);
              return;
            }else if(res.data.retStatus === 0){
              Toast({
                message: '操作成功:已驳回',
                iconClass: 'icon icon-success'
              });
              _this.$router.push({
                path: '/purchase/store/list',
                query:{entryType:_this.entryType}
              })
            }
          },function (err) {

          });
        })

      },
      submit (type) {
        this.status = type;
      },
      getProccess (success) {
        console.log(this.audit)
        let param = {
          orderId: this.audit.orderNo,
          companyId: this.userHistory.companyId,
        };
        getApproveProcessYsk(param,function (res) {
          success(res.data.retData);
        },function (err) {

        });
      },

    },
    created() {
    },
    mounted() {
      let params = {
        companyId: this.userHistory.companyId,
        billNo: this.audit.orderNo,
        "offset":0,
        "limit":1
      },_this = this;
      getStoreDetailYsk(params,function (res) {
        console.log(res);
        if(res.data.retStatus === 1){
          Toast(res.data.retDesc);
          return;
        }
        _this.detailInfo = res.data.retData.rows[0];
        let param = {
          companyId: _this.userHistory.companyId,
          orgId: _this.userHistory.orgId
        },products = [];
        for(let i = 0 ; i < _this.detailInfo.details.length ; i++){
          products.push(_this.detailInfo.details[i].productId);
          _this.detailInfo.details[i].hzNum = ''
        }
      },function (err) {

      });
    },
    computed: {
      ...mapGetters([
        'audit',
        'userHistory'
      ])
    }
  }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .slide-enter-active, .slide-leave-active{
    transition: all 0.3s
  }
  .slide-enter, .slide-leave-to{
    transform: translate3d(100%, 0, 0)
  }
  .slide-fade-enter-active {
    transition: all .3s ease;
  }
  .slide-fade-leave-active {
    transition: all .3s ease;
  }
  .slide-fade-enter, .slide-fade-leave-to
    /* .slide-fade-leave-active for below version 2.1.8 */ {
    transform: translateY(10px);
    opacity: 0;
  }
  .help{
    position: absolute;
    right: 0;
    top: 1.43rem;
    color: red;
  }
</style>
