<template>
  <div>
    <ysl-header :title = 'audit.orderTypeName'></ysl-header>
    <audit-header :avator="avator" :orderTypeName="audit.orderTypeName" :selectType="selectType"></audit-header>

    <form>
      <div class="audit-view">
        <audit-proccess :getProcess="getProccess"></audit-proccess>

        <div class="module-item">
          <div class="module-header" :class="{'isSpread' : false}">
            <span>基础信息</span>
          </div>
          <div class="module-main">
            <p class="p-base"><label>单据号</label>{{detailInfo.billNo}}</p>
            <p class="p-base"><label>制单单位</label>{{detailInfo.orgName}}</p>
            <p class="p-base"><label>制单人</label>{{detailInfo.staffName}}</p>
            <p class="p-base"><label>制单日期</label>{{detailInfo.addTime | formatDate}}</p>
          </div>
        </div>
        <div class="module-item">
          <div class="module-header" :class="{'isSpread' : false}">
            <span>客户信息</span>
          </div>
          <div class="module-main">
            <p class="p-base"><label>客户</label>{{detailInfo.customerName}}</p>
            <p class="p-base"><label>结算方式</label>{{detailInfo.modeName}}</p>
            <p class="p-base"><label>结算金额</label>{{detailInfo.settleMoney}}</p>
          </div>
        </div>
        <div class="module-item">
          <div class="module-header" @click="show('assist')" :class="{'isSpread' : false}">
            <span>
              {{detailInfo.settleMode==1 ? '返利' : detailInfo.settleMode==0 ? '价保' : '预收款' }}
            </span>
          </div>
          <div class="module-main">
            <p class="p-base p-title"><label>使用合计</label>{{detailInfo.settleMoney}}</p>
            <div class="product-info" v-for="item in detailInfo.useVOS">
              <p class="p-base"><label>单据号</label>{{item.settlementId}}</p>
              <p class="p-base"><label>客户</label>{{item.customerName}}</p>
              <p class="p-base"><label>返利金额</label>{{item.settleMoney}}</p>
              <p class="p-base"><label>可使用返利</label>{{item.totalMoney}}</p>
              <p class="p-base"><label>本次使用</label>{{item.leftMoney}}</p>
            </div>
          </div>
        </div>
        <div class="module-item">
          <div class="module-header" @click="show('assist')" :class="{'isSpread' : false}">
            <span>关联批发订单信息</span>
          </div>
          <div class="module-main">
            <p class="p-base p-title"><label>申请合计</label>{{detailInfo.settleMoney}}</p>
            <div v-for="item in detailInfo.details">
              <div  class="product-info">
                <p class="p-base"><label>批发单号</label>{{item.orderNo}}</p>
                <p class="p-base"><label>已结算金额</label>{{detailInfo.settledMoney}}</p>
                <p class="p-base"><label>待结算金额</label>{{item.settleMoney - detailInfo.settledMoney}}</p>
                <p class="p-base"><label>申请结算</label>{{item.settleMoney}}</p>
                <!--<p class="p-base"><label>已核销发票</label>{{item.moneyToSettle}}</p>-->
                <!--<p class="p-base"><label>待核销发票</label>{{item.invoiceToCheck}}</p>-->
              </div>
              <div v-for="item2 in item.orderVO.goods">
                <p class="p-base p-title">{{item2.productName}}</p>
                <p class="p-base"><label>批发单价</label>{{item2.orderPrice}}</p>
                <p class="p-base"><label>批发数量</label>{{item2.orderNum}}</p>
                <p class="p-base"><label>批发总价</label>{{item2.orderNum * item2.orderPrice}}</p>
                <p class="p-base"><label>实出数量</label>{{item2.amountAlreadyOut}}</p>
                <p class="p-base"><label>待出数量</label>{{item2.amountToOut}}</p>
              </div>
            </div>
          </div>
        </div>
        <div class="module-item">
          <div class="module-header" :class="{'isSpread' : false}">
            <span>单据备注</span>
          </div>
          <div class="module-main">
            <p class="p-base">{{detailInfo.remark || '暂无备注'}}</p>
          </div>
        </div>
        <div class="module-item">
          <div class="module-header header-yellow" :class="{'isSpread' : false}">
            <span>审核备注</span>
          </div>
          <div class="module-main">
            <div class="audit-remark">
              <input type="text" v-model="remark" placeholder="（非必填）写备注..."/>
            </div>
          </div>
        </div>
      </div><!--audit-view-->
      <div class="audit-foot">
        <button @click="submitY()" type="button" class="green">同意</button>
        <button @click="submitN()" type="button" class="reject">驳回</button>
        <button class="remark">备注</button>
      </div>
    </form>
  </div>
</template>

<script type="text/ecmascript-6">
  import yslHeader from '@/components/base/header/header'
  import auditProccess from '@/components/base/audit/audit-proccess'
  import auditHeader from '@/components/base/audit/audit-header'
  import {mapGetters} from 'vuex'
  import {getStoreDetailOther,storeApproveOtherY,storeApproveOtherN,getApproveProcessOther} from  'assets/js/api/wholesaleApi'
  import {dateFormat} from 'assets/js/util'
  import avator from '../../../assets/avator.png'
  import { Toast , MessageBox } from 'mint-ui'
  export default {
    components: {
      yslHeader,
      auditProccess,
      auditHeader
    },
    filters: {
      formatDate(time) {
        var date = new Date(time);
        return dateFormat(date,'yyyy-MM-dd hh:mm:ss');
      }
    },
    data () {
      return {
        val : '',
        text : '',
        remark : '',
        avator : avator,
        sequence : false,
        assist : false,
        additional : false,
        stocks : [],
        products : [],
        auxiliary : [],
        detailInfo: {},
        status: 0,
      }
    },
    methods: {
      show (type) {
        switch (type){
          case 'sequence':
            this.sequence = !this.sequence;
            break;
          case 'assist':
            this.assist = !this.assist;
            break;
          case 'additional':
            this.additional = !this.additional;
            break;
        }
      },
      submitY(){
        let _this = this;
        let param = {
          orderId : this.detailInfo.settlementId,
          comment : this.remark,
          companyId: this.userHistory.companyId,
          orgId:this.userHistory.orgId,
          staffId: this.userHistory.staffId,
        }
        MessageBox.confirm('确定执行此操作?').then(action => {
          storeApproveOtherY(param,function (res) {
            if(res.data.retStatus === 1){
              Toast(res.data.retDesc);
              return;
            }else if(res.data.retStatus === 0){
              Toast({
                message: '操作成功:已同意',
                iconClass: 'icon icon-success'
              });
              _this.$router.push({
                path: '/purchase/store/list',
                query:{entryType:_this.entryType}
              })
            }
          },function (err) {

          });
        })


      },
      submitN(){
        let _this = this;
        let param = {
          orderId : this.detailInfo.settlementId,
          comment : this.remark,
          companyId: this.userHistory.companyId,
          orgId:this.userHistory.orgId,
          staffId: this.userHistory.staffId,
        }
        MessageBox.confirm('确定执行此操作?').then(action => {
          storeApproveOtherN(param,function (res) {
            if(res.data.retStatus === 1){
              Toast(res.data.retDesc);
              return;
            }else if(res.data.retStatus === 0){
              Toast({
                message: '操作成功:已驳回',
                iconClass: 'icon icon-success'
              });
              _this.$router.push({
                path: '/purchase/store/list',
                query:{entryType:_this.entryType}
              })
            }
          },function (err) {

          });
        })
      },
      submit (type) {
        this.status = type;
      },
      getProccess (success) {
        let param = {
          orderId: this.audit.orderNo,
          companyId: this.userHistory.companyId,
        };
        getApproveProcessOther(param,function (res) {
          success(res.data.retData);
        },function (err) {

        });
      },
    },
    created() {
    },
    mounted() {
      let params = {
        companyId: this.userHistory.companyId,
        billNo: this.audit.orderNo,
        "offset":0,
        "limit":1
      },_this = this;
      getStoreDetailOther(params,function (res) {
        if(res.data.retStatus === 1){
          Toast(res.data.retDesc);
          return;
        }
        _this.detailInfo = res.data.retData.rows[0];
        let param = {
          companyId: _this.userHistory.companyId,
          orgId: _this.userHistory.orgId
        },products = [];

      },function (err) {

      });
    },
    computed: {
      ...mapGetters([
        'audit',
        'userHistory'
      ])
    }
  }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .slide-enter-active, .slide-leave-active{
    transition: all 0.3s
  }
  .slide-enter, .slide-leave-to{
    transform: translate3d(100%, 0, 0)
  }
  .slide-fade-enter-active {
    transition: all .3s ease;
  }
  .slide-fade-leave-active {
    transition: all .3s ease;
  }
  .slide-fade-enter, .slide-fade-leave-to
    /* .slide-fade-leave-active for below version 2.1.8 */ {
    transform: translateY(10px);
    opacity: 0;
  }
  .help{
    position: absolute;
    right: 0;
    top: 1.43rem;
    color: red;
  }
</style>
