<template>
  <div class="guide" v-bind:style="{height : guideHeight + 'px'}">
     <img class="logo" :src="logo" >
  <div class="description"></div>
  <div class="version">{{version}}</div>
  </div>
</template>

<script>
	import logo from './img/logo.png'
	export default{
		data(){
			return {
        logo: logo,
        guideHeight : this.getHeight(),
        version : '0'
      }
		},
		mounted(){
      var that = this;
		  this.version = 'versionCode2.0.0';
		  setTimeout(function () {
        that.$router.push('/login');
      },3000);
		},
		methods:{
      getHeight(){
			  return document.documentElement.clientHeight;
      }
		}
	}
</script>

<style lang="scss" scoped >
  @import "../../assets/scss/const.scss";
  .guide{
    background-color: $guide-bg;
    height:100%;
    transition: all ease-out 0.3s;
  }
  .description{
    background: url("./img/description.png") center no-repeat;
    height: .341rem;
    margin-top: 0.93rem;
    background-size: auto 100%;
  }
  .logo{
    margin-top: 4.949rem;
    width: 3.92rem;
  }
  .version{
    position: absolute;
    bottom: 0.853rem;
    text-align:center;
    font-size:0.187rem;
    color:#fff;
    width:100%;
  }
</style>
