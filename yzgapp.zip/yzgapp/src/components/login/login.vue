<!-- 登录 组件 -->

<template>
  <div class="login">
    <img class="logo" :src="logo"/>
    <!-- 登录 -->
    <mt-tab-container-item class="login-wrapper">
      <mt-field label="用户名" placeholder="请输入用户名"  type="text" v-model="login_username"></mt-field>
      <mt-field label="密码" placeholder="请输入密码"  type="password" v-model="login_password"></mt-field>
      <mt-button type="default" size="large" @click.native="_login">登录</mt-button>
      <div class="login-link">
        <router-link :to="{path:'./register'}">
          <a class="register" href="javascript:;">申请试用</a>
        </router-link>
        <a class="forget" href="javascript:;">忘记密码</a>
      </div>
    </mt-tab-container-item>
  </div>
</template>

<script>
  import logo from './img/login-logo.png'
  import { Toast } from 'mint-ui';
  import {mapGetters} from 'vuex'
  import {login} from 'assets/js/api/recommend'
  import md5 from 'js-md5'
  import {mapActions} from 'vuex'
  export default {
    data () {
      return {
        selected: '1',
        login_username: '',
        login_password: '',
        logo : logo,
        Password:'',
        errMsg: ''
      }
    },
    props: {},
    watch: {
      login_username: function (val) {
      },
      login_password: function (val) {
      }
    },
    methods: {
      checkEmpty (ruleValue) {
        return ruleValue.trim() ? true : false
      },
      checkReg (ruleValue,value){
        return ruleValue.test(value) ? true : false
      },
      back () {
        this.$router.push({
          path: '/index'
        })
      },
      _login () {
        let _this = this;
        const Mobile = /^1[3|4|5|7|8]\d{9}$/;
        if(!_this.checkEmpty(this.login_username)){
          Toast('用户名不能为空');
          return;
        }
        if(!_this.checkReg(Mobile,this.login_username)){
          Toast('请输入正确的手机号');
          return;
        }
        if(!_this.checkEmpty(this.login_password)){
          Toast('密码不能为空');
          return;
        }
        let params = {
          telphone: this.login_username,
          password: md5(md5("YLS_888"+this.login_password))
        }
        login(params,function (res) {
          if(res.data.retStatus === 0){
            _this.saveUserHistory(res.data.retData)
            Toast({message:'登录成功',duration: 2000});
            _this.$destroy();
            _this.$router.push({
              path: '/home'
            })
          }else{
            Toast({message: res.data.retDesc,duration: 3000});
          }
        },function (err) {
          Toast(err.message);
        });
      },
      changeForm () {
        console.log(this.login_username+" "+this.login_password)
      },
      ...mapActions([
        'saveUserHistory',
        'deleteUserHistory'
      ])
    },
    filters: {},
    computed: {
      ...mapGetters([
        'userHistory'
      ])
    },
    created () {
    },
    mounted () {
      let _this = this;
      if(_this.userHistory){
        _this.login_username = _this.userHistory.telphone
        _this.login_password = _this.userHistory.initPassword
        _this.deleteUserHistory(_this.userHistory);
      }
    }
  }
</script>

<style lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .logo{
    width: 3.49rem;
    margin-top: 3.09rem;
  }
  .login {
    color: #333;
    background-color: #fff;
    overflow: visible;
    padding: 0 1.813rem;
    .login-wrapper {
      overflow: hidden;
      margin-top: 1.518rem;
      .mint-cell{
        min-height: auto;
        margin-bottom:0.773rem;
      }
    }
    .register-wrapper {
      margin-top: 20px;
      overflow: hidden;
      .mint-button {
        margin-top: 30px;
      }
    }
    .login-link{
      display: flex;
      margin-top: 0.533rem;
      a{
        display: flex;
        flex: 1;
        font-size: $font-size-medium;
        color:$color-text-d;
      }
      .forget{
        justify-content: flex-end;
      }
    }
  }
</style>
