<template>
  <div>
    <audit-list v-infinite-scroll="scroll"
                :infinite-scroll-disabled="loading && !hasMore"
                infinite-scroll-distance="10" @select="selectSh" :data="data" />
    <p class="loadingnone" v-show="!hasMore">没有更多了</p>
    <p class="page-infinite-loading" v-show="loading">
      <mt-spinner type="fading-circle" ></mt-spinner>
      加载中...
    </p>
  </div>
</template>

<script>
  import auditList from '@/components/base/audit/list'
  import { Toast } from 'mint-ui';
  export default {
    data () {
      return {
        data: [],
        hasMore: true,
        loading: false,
      }
    },
    components: {
      auditList
    },
    props: {
      loadData: {
        type: Function,
        require: true
      },
      loadSize: {
        type: Number,
        default: 10
      },
      type: {
        type: Number,
        default: 0
      }
    },
    filters: {

    },
    methods: {
      scroll() {
        let me = this;
        if(!me.loading && me.hasMore) {
          me.loading = true;
          setTimeout(()=>{
            me.loadData((result,total) => {
              if(result.length === 0){
                me.hasMore = false;
                me.loading = false;
                return;
              }
              if (result && result.length > 0) {
                me.data = me.data.concat(result);
                if (result.length < me.loadSize) {
                  me.hasMore = false;
                }
                me.loading = false;
              }
              if(total < 10){
                me.hasMore = true;
              }
            },(err)=>{
              me.loading = false;
            });
          },1000);
        }
      },
      selectSh(audit) {
        console.log(audit);
        this.$emit('selectSh',audit)
      },
    },
    watch: {
      type () {
        this.loading = false;
        this.hasMore = true;
        this.data = [];
        this.scroll();
      }
    }
  }
</script>
<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
</style>
