<template>
    <div class="audit-tab">
      <mt-navbar fixed v-model="selected">
        <mt-tab-item id="1"><span>待我审核({{expireNumber}})</span></mt-tab-item>
        <mt-tab-item id="2"><span>我已审核</span></mt-tab-item>
      </mt-navbar>
      <mt-tab-container v-model="selected">
        <mt-tab-container-item id="1">
          <load-more v-if="selected==1" @selectSh="selectSh($event)" :type="type" :loadSize="pageSize" :loadData="_loadwillMore" />
        </mt-tab-container-item>
        <mt-tab-container-item id="2">
          <load-more v-if="selected==2" @selectSh="selectSh($event)" :type="type" :loadSize="pageSize" :loadData="_loadMore" />
        </mt-tab-container-item>
      </mt-tab-container>
    </div>
</template>

<script>
  import loadMore from '@/components/base/audit/loadMore'
  import {auditType} from 'assets/js/config'
  import {mapMutations,mapGetters} from 'vuex'
    export default {
      data() {
        return {
          selected: '1'
        }
      },
      created () {
      },
      props: {
        loadMore: {
          type: Function,
          require: true
        },
        loadwillMore: {
          type: Function,
          require: true
        },
        type: {
          type: Number,
          default: 0
        },
        expireNumber: {
          type: Number,
          default: 0
        },
        pageSize: {
          type: Number,
          default: 10
        },
        entryType: {
          type: String,
          default: ''
        },
      },
      components: {
        loadMore
      },
      methods: {
        selectSh (audit) {
          console.log(this.entryType);
          let type = audit.orderType,val = audit.id
          audit.selectId = parseInt(this.selected)
          this.$router.push({
            path: '/purchase'+auditType[type]+'/'+val,
            query:{entryType:this.entryType}
          })
          this.setAudit(audit)
        },
        _loadMore(cb,error) {
          let _this = this;
          _this.loadMore((result) => {
            cb(result,_this.expireNumber);
          },(err)=>{
            error(err);
          })
        },
        _loadwillMore (cb,error){
          let _this = this;
          _this.loadwillMore((result) => {
            cb(result,_this.expireNumber);
          },(err)=>{
            error(err);
          })
        },
        ...mapMutations({
          setAudit: 'SET_AUDIT'
        })
      },
      mounted () {
      },
      computed: {
        ...mapGetters(['userHistory'])
      },
      watch: {
        selected () {
          this.$emit('selected',this.selected)
        }
      },
    }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .mint-navbar{
    top: $header-height;
    margin:$pdding-normal;
    border-radius:$radius;
    box-shadow: $shadow;
    z-index: 2;
    span {
      display: inline-block;
      height:$sh-height;
      line-height: $sh-height;
      font-size: $font-size-16;
      color: $guide-bg;
    }
  }
  .mint-navbar .mint-tab-item{
    padding: 0;
    height: $sh-height;
  }
  .mint-navbar .mint-tab-item.is-selected{
    border-bottom: 0;
    span {
      border-bottom: $border-size solid $guide-bg !important;
    }
  }
  .audit-tab /deep/ .mint-spinner-triple-bounce{
    margin-top: 0.853rem;
  }
  .audit-tab /deep/ .page-infinite-loading{
    margin-top: 0.426rem;
    text-align: center;
    .mint-spinner-fading-circle{
      display: inline-block;
      vertical-align: middle;
    }
  }
</style>
