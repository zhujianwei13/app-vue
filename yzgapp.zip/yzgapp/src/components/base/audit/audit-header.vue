<template>
  <div class="audit-view-header">
    <img class="avator" :src="avator"/>
    <div class="orderDetail">
      <div>
        <h3>{{orderTypeName}}</h3>
        <p v-if="selectType === 1">待审核</p>
        <p v-else>已审核</p>
      </div>
    </div>
  </div>
</template>

<script>
    export default {
      name: "audit-header",
      props:['avator','orderTypeName','selectType']
    }

</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';

</style>
