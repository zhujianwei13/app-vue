<template>
  <div class="search">
    <div class="search-tab">
      <div class="search-item" @click="search"><i class="icon iconfont icon-sousuoon"></i>搜索</div>
      <div class="search-item" @click="filter"><i class="icon iconfont icon-shaixuan"></i>筛选</div>
    </div>
    <div class="search-main" v-show="searchView">
      <div class="search-input">
        <i class="icon iconfont icon-sousuoon"></i>
        <input type="text" value=""/>
        <button class="cancle" @click="cancle">取消</button>
      </div>
      <div class="search-tip">
        <div class="h3"><span>在这里您尝试通过以下条件搜索</span></div>
        <ul>
          <li>
            <div>
              <img :src="icon.icon4">
              <p>单据名称</p>
            </div>
          </li>
          <li>
            <div>
              <img :src="icon.icon3">
              <p>单据号</p>
            </div>
          </li>
          <li>
            <div>
              <img :src="icon.icon2">
              <p>制单单位</p>
            </div>
          </li>
          <li>
            <div>
              <img :src="icon.icon1">
              <p>制单人</p>
            </div>
          </li>
        </ul>
      </div>
    </div>
    <transition name="fade">
    <div class="filter" v-show="filterView">
      <ul>
        <li :class="{active : resultNum === 0}" @click="change(0)">
          <span>全部</span>
        </li>
        <li v-for="item in typeList" :class="{active : resultNum === item.orderType}" @click="change(item.orderType)">
          <span>{{item.orderTypeName}}</span>
        </li>
      </ul>
    </div>
    </transition>
  </div>
</template>
<script>
  import icon1 from './img/icon1.png'
  import icon2 from './img/icon2.png'
  import icon3 from './img/icon3.png'
  import icon4 from './img/icon4.png'
  import {mapGetters} from 'vuex'
  export default {
    data () {
      return {
        searchView: false,
        filterView: false,
        icon : {
          icon1 :icon1,
          icon2 :icon2,
          icon3 :icon3,
          icon4 :icon4,
        }
      }
    },
    props: {
      typeList: {
        type: Array,
        default: []
      },
      resultNum: {
        type: Number,
        default: 0
      },
    },
    methods: {
      search () {
        this.searchView = !this.searchView;
        this.filterView = false;
      },
      filter () {
        this.filterView = !this.filterView;
        this.searchView = false;
      },
      cancle () {
        this.searchView = false;
      },
      change (type) {
        this.filterView = false;
        this.$emit('changeType',type)
      }
    },
    computed: {
      ...mapGetters(['userHistory'])
    },
    mounted () {

    }
  }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .search-main,.filter{
    position: fixed;
    left: 0;
    top: 0;
    height: 100%;
    right: 0;
    padding-top:3.968rem ;
    background-color: $main-bg;
  }
  .filter{
    padding-top: 3.993rem;
    ul{
      display: flex;
      flex-wrap: wrap;
      padding: 0 $gap;
      .active{
        span{
          background-color: $guide-bg;
          color: $main-bg;
        }
      }
      li{
        padding: 0 0.503rem;
        display: flex;
        width: 50%;
        flex-direction: column;
        flex: 1;
        min-width: 50%;
        max-width: 50%;
        margin-bottom: 0.683rem;
        span{
          height: 1.013rem;
          line-height: 1.013rem;
          border-radius: 3px;
          font-size: $font-size-medium;
          color: $guide-bg;
        }
      }
    }
  }
  .search-tab{
    position: fixed;
    top: 2.346rem;
    right: $gap;
    left: $gap;
    display: flex;
    background-color:$main-bg;
    box-shadow:$shadow-list;
    z-index: 1;
    .search-item{
      display:flex;
      flex: 1;
      width: 50%;
      height: 1.143rem;
      line-height: 1.143rem;
      color:$color-text-e;
      justify-content:center;
      font-size: $font-size-medium;
      .icon{
        margin-right: $gap;
      }
    }
  }
  .search-input{
    position: relative;
    border: 1px solid #98afc5;
    margin: 0.266rem 0.533rem;
    border-radius: 3px;
    .cancle{
      position: absolute;
      top: 0;
      right: 0;
      height: 0.823rem;
      border: none;
      font-size: $font-size-medium;
      color: $guide-bg;
    }
    .icon{
      position: absolute;
      color: $guide-bg !important;
      margin-left: 0.256rem;
      margin-top: 0.128rem;
    }
    input[type='text']{
      margin-bottom:0;
      padding: 0 0.96rem;
      border: none;
      border-radius: 3px;
      height: 0.823rem;
      font-size: $font-size-12;
    }
  }
  .search-tip{
    margin: 0.559rem 0.533rem 0 0.533rem;
    .h3{
      @include onepx('bottom');
      text-align: center;
      height: 0;
      span{
        position: absolute; left: 50%; top: 50%;
        transform: translate(-50%, -50%);
        padding: 0 0.106rem;
        font-size: $font-size-12;
        line-height: 1;
        color: $color-text-b6;
        background-color: $main-bg;
        z-index: 1;
        width: 5.12rem;
      }
    }
    ul{
      padding-top: 0.93rem;
      display: flex;
      li{
        display: flex;
        flex: 1;
        justify-content: center;
        img{
          height:0.586rem;
        }
      }
    }
  }
  .fade-enter-active, .fade-leave-active {
    transition: opacity .5s;
  }
  .fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
    opacity: 0;
  }
</style>
