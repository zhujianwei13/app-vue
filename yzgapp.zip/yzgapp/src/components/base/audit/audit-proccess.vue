<template>
  <div class="module-item">
    <div class="module-header" @click="show('sequence')" :class="{'isSpread' : sequence}">
      <span>审核流程</span>
      <i class="icon iconfont icon-xialajiantou"></i>
    </div>
    <transition name="slide-fade">
      <div class="moudle-main" v-show="sequence">
        <div class="audit-flow" v-if="approveProccess.length != 0">
          <div class="flow-item">
            <div class="avator">
              <img :src="avator"/>
            </div>
            <div class="avator-info">
              <div>
                <div class="avator-info-t">
                  <div class="avator-item">{{audit.makeOrderStaffName}}</div>
                  <div class="avator-item" :class="approveStatus[0].className">{{approveStatus[0].text}}</div>
                  <div class="avator-item audit-time">{{audit.addTime | formatDate}}</div>
                </div>
                <p></p>
              </div>
            </div>
          </div>
          <div class="flow-item" v-for="item in approveProccess" v-if="item.status != 0">
            <div class="avator">
              <img :src="avator"/>
            </div>
            <div class="avator-info">
              <div>
                <div class="avator-info-t">
                  <div class="avator-item">{{item.staffName}}</div>
                  <div class="avator-item" :class="approveStatus[item.status].className">{{approveStatus[item.status].text}}</div>
                  <div class="avator-item audit-time">{{item.addTime | formatDate}}</div>
                </div>
                <p>{{item.comment}}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </transition>
  </div>
</template>

<script>
  import avator from '../../../assets/avator.png'
  import {getApproveProcess} from 'assets/js/api/purchase'
  import {approveStatus} from 'assets/js/config'
  import {mapGetters} from 'vuex'
    export default {
      data () {
        return {
          approveProccess: [],
          sequence : false,
          approveStatus:approveStatus,
          avator : avator
        }
      },
      props:{
        getProcess: {
          type: Function,
          require: true
        }
      },
      methods: {
        show (type) {
          switch (type){
            case 'sequence':
              this.sequence = !this.sequence;
              break;
            case 'assist':
              this.assist = !this.assist;
              break;
            case 'additional':
              this.additional = !this.additional;
              break;
          }
        },
      },
      computed: {
        ...mapGetters([
          'audit'
        ])
      },
      mounted () {
        let _this = this;
        this.getProcess((result) => {
          if(Array.isArray(result)){
            _this.approveProccess = result;
          }
        })
      }
    }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .slide-enter-active, .slide-leave-active{
    transition: all 0.3s
  }
  .slide-enter, .slide-leave-to{
    transform: translate3d(100%, 0, 0)
  }
  .slide-fade-enter-active {
    transition: all .3s ease;
  }
  .slide-fade-leave-active {
    transition: all .3s ease;
  }
  .slide-fade-enter, .slide-fade-leave-to
    /* .slide-fade-leave-active for below version 2.1.8 */ {
    transform: translateY(10px);
    opacity: 0;
  }
</style>
