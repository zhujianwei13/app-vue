<template>
  <div class="audit-list" :data="data">
    <ul>
      <li v-for="item in data" class="list-group" ref="listGroup" @click="selectItem(item)">
        <div class="avatar">
          <img class="" :src="avator" >
        </div>
        <div class="sh-detail">
          <div>
            <h3>{{item.orderTypeName}}（{{item.makeOrderOrgName}}）</h3>
            <p><label>单据号</label>{{item.orderNo}}</p>
            <p><label>制单单位</label>{{item.makeOrderOrgName}}</p>
            <p><label>制单人</label>{{item.makeOrderStaffName}}</p>
            <p>
              <span v-if="!item.approveStatus" class="status-will">待审核</span>
              <span v-else :class="approveStatus[item.approveStatus].className">{{approveStatus[item.approveStatus].text}}</span>
            </p>
            <span class="status">{{item.statusName}}</span>
            <span class="time">{{item.addTime | formatDate | subTime}}</span>
          </div>

        </div>
      </li>
    </ul>
  </div>
</template>

<script>
  import avator from 'assets/avator.png'
  import {dateFormat} from 'assets/js/util'
  import {approveStatus} from 'assets/js/config'
  export default {
    data () {
      return {
        avator : avator,
        approveStatus:approveStatus
      }
    },
    props: {
      data: {
        type: Array,
        default: []
      }
    },
    filters: {
      formatDate(time) {
        var date = new Date(time);
        return dateFormat(date, 'yyyy-MM-dd hh:mm');
      },
      subTime(value){
        let date = value.substr(5,value.length-5);
        return date;
      }
    },
    methods: {
      selectItem(item) {
        this.$emit('select', item)
      }
    }
  }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .audit-list{
    ul{
      .list-group{
        display: flex;
        padding: $gap;
        box-shadow: $shadow-list;
        .avatar{
          display: flex;
          width:0.981rem;
          img{
            width:0.981rem;
            height:0.981rem;
          }
        }
        .sh-detail{
          position: relative;
          display: flex;
          flex:1;
          margin-left: $gap;
          text-align: left;
          h3{
            line-height: 0.586rem;
            color: $color-text-title;
            font-size:$font-size-medium;
            margin-bottom:0.085rem;
            margin-top: 0;
          }
          p{
            line-height: 0.512rem;
            font-size:$font-size-12;
            color: $color-text-a;
            margin-bottom: 0;
            label{
              display: inline-block;
              width:1.866rem;
            }
          }
          .status{
            position: absolute;
            right: 0;
            bottom: 0;
            font-size:$font-size-12;
            color: $guide-bg;
            line-height: 0.512rem;
          }
          .time{
            position: absolute;
            right: 0;
            top: 0;
            font-size:$font-size-12;
            color: $color-text-a;
            line-height: 0.586rem;
          }
        }
      }
    }
  }
</style>
