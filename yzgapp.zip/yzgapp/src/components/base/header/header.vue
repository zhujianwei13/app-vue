<template>
  <mt-header fixed :title="title" class="yzg-header">
    <a href="javascript:;" onclick="window.history.go(-1)" slot="left">
      <mt-button icon="back"></mt-button>
    </a>
  </mt-header>
</template>

<script>
  export default {
    components: {},
    props:{
      title: {
        type: String
      }
    },
    watch: {},
    methods: {
      back () {
        $router.go(-1)
      }
    },
    filters: {},
    computed: {},
    created () {},
    mounted () {
    },
    destroyed () {}
  }
</script>

<style scoped lang="scss">
  @import '~@/assets/scss/const.scss';
  @import '~@/assets/scss/mixin.scss';
  @import '~@/assets/scss/global.scss';
  .mint-button--normal{
    background: none !important;
  }
  .yzg-header{
    font-size: $font-size-18 !important;
    z-index: 2;
  }
</style>
