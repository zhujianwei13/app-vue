// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router/index'
import '../static/js/mui.js'
import store from './store'
import {dateFormat} from 'assets/js/util'
import 'lib-flexible'
Vue.config.productionTip = false

// 将全局样式文件写在 main.js
import '@/assets/scss/reset.scss'
import '@/assets/ali-fonts/iconfont.css'
import '../static/css/mui.min.css'

// Mint UI
import Mint from 'mint-ui'
import 'mint-ui/lib/style.css'
import { Toast } from 'mint-ui';
Vue.use(Mint);
//侧滑
import DrawerLayout from 'vue-drawer-layout'
Vue.use(DrawerLayout);
//表单验证
import VeeValidate from 'vee-validate';
import zh_CN from 'vee-validate/dist/locale/zh_CN'
import VueI18n from 'vue-i18n';
Vue.use(VueI18n)
const i18n = new VueI18n({
  locale: 'zh_CN',
})
Vue.use(VeeValidate, {
  i18n,
  i18nRootKey: 'validation',
  dictionary: {
    zh_CN
  }
});
//保留两位小数
Vue.filter('twoPoint',function (value) {
  value = Number(value);
  return value.toFixed(2)
})
Vue.filter('formatDate',function (time) {
  let date = new Date(time);
  return dateFormat(date, 'yyyy-MM-dd');
});
router.beforeEach(function (to, from, next) {
  if (to.matched.length ===0) {
    if(to.path.includes('view')){
      Toast({
        message: '暂不支持此类单据审核，我们将尽快支持，敬请期待。',
        duration: 1000
      });
    }else {
      Toast({
        message: '我们将尽快支持此功能，敬请期待。',
        duration: 1000
      });
    }
    next(false)
  } else {
    next()
  }
})
/* eslint-disable no-new */
new Vue({
  el: 'body',
  router,
  store,
  components: { App },
  template: '<App/>'
})
